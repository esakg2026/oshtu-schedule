import SwiftUI
import UserNotifications
import WebKit
import WidgetKit

/// Показывать напоминания со звуком, даже когда приложение открыто.
final class NotificationDelegate: NSObject, UNUserNotificationCenterDelegate {
    static let shared = NotificationDelegate()

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification,
                                withCompletionHandler completion: @escaping (UNNotificationPresentationOptions) -> Void) {
        completion([.banner, .sound, .list])
    }
}

@main
struct OshtuApp: App {
    @Environment(\.scenePhase) private var phase

    init() {
        UNUserNotificationCenter.current().delegate = NotificationDelegate.shared
    }

    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .onChange(of: phase) { p in
            if p == .active {
                Task {
                    try? await API.fetch()
                    Reminders.reschedule()
                }
            }
            if p == .background {
                WidgetCenter.shared.reloadAllTimelines()
                Reminders.reschedule()
            }
        }
    }
}

struct RootView: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        WebContainer()
            .background(scheme == .dark ? Color(red: 13 / 255, green: 15 / 255, blue: 23 / 255)
                                        : Color(red: 244 / 255, green: 245 / 255, blue: 251 / 255))
            .ignoresSafeArea(.container, edges: .bottom)
    }
}

/// Веб-версия расписания + мост `window.webkit.messageHandlers.oshtu` для передачи настроек виджету и напоминаниям.
struct WebContainer: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .default()
        cfg.userContentController.add(context.coordinator, name: "oshtu")
        cfg.applicationNameForUserAgent = "OshtuiOS/1.1"
        let web = WKWebView(frame: .zero, configuration: cfg)
        web.isOpaque = false
        web.backgroundColor = .clear
        web.scrollView.backgroundColor = .clear
        web.allowsBackForwardNavigationGestures = true
        web.navigationDelegate = context.coordinator
        var comps = URLComponents(url: AppConfig.site, resolvingAgainstBaseURL: false)!
        comps.queryItems = [URLQueryItem(name: "source", value: "ios")]
        web.load(URLRequest(url: comps.url!))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "oshtu", let json = message.body as? String else { return }
            if let d = json.data(using: .utf8),
               let obj = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
               obj["action"] as? String == "testReminder" {
                Reminders.test()
                return
            }
            let before = Store.settings?.notify ?? 0
            Store.saveSettings(json: json)
            WidgetCenter.shared.reloadAllTimelines()
            let notify = Store.settings?.notify ?? 0
            Task {
                try? await API.fetch()
                if notify > 0 && before == 0 {
                    Reminders.requestPermission { _ in Reminders.reschedule() }
                } else {
                    Reminders.reschedule()
                }
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = action.request.url, let host = url.host, host != AppConfig.site.host,
               action.navigationType == .linkActivated {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
    }
}
