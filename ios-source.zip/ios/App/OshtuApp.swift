import SwiftUI
import WebKit
import WidgetKit

@main
struct OshtuApp: App {
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .onChange(of: phase) { p in
            if p == .background {
                WidgetCenter.shared.reloadAllTimelines()
            }
        }
    }
}

struct RootView: View {
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        WebContainer()
            .background(scheme == .dark ? Color(red: 13 / 255, green: 15 / 255, blue: 23 / 255)
                                        : Color(red: 244 / 255, green: 245 / 255, blue: 251 / 255))
            .ignoresSafeArea(.container, edges: .bottom)
    }
}

/// Веб-версия расписания + мост `window.webkit.messageHandlers.oshtu` для передачи настроек виджету.
struct WebContainer: UIViewRepresentable {
    func makeCoordinator() -> Coordinator { Coordinator() }

    func makeUIView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .default()
        cfg.userContentController.add(context.coordinator, name: "oshtu")
        cfg.applicationNameForUserAgent = "OshtuiOS/1.0"
        let web = WKWebView(frame: .zero, configuration: cfg)
        web.isOpaque = false
        web.backgroundColor = .clear
        web.scrollView.backgroundColor = .clear
        web.allowsBackForwardNavigationGestures = true
        web.navigationDelegate = context.coordinator
        var comps = URLComponents(url: AppConfig.site, resolvingAgainstBaseURL: false)!
        comps.queryItems = [URLQueryItem(name: "source", value: "ios")]
        web.load(URLRequest(url: comps.url!))
        return web
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKScriptMessageHandler, WKNavigationDelegate {
        func userContentController(_ controller: WKUserContentController, didReceive message: WKScriptMessage) {
            guard message.name == "oshtu", let json = message.body as? String else { return }
            Store.saveSettings(json: json)
            WidgetCenter.shared.reloadAllTimelines()
        }

        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = action.request.url, let host = url.host, host != AppConfig.site.host,
               action.navigationType == .linkActivated {
                UIApplication.shared.open(url)
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }
    }
}
