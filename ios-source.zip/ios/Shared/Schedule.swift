import Foundation

// Общий код приложения и виджета: настройки, загрузка, кэш и разбор расписания ОшТУ
// (та же логика, что в core.js веб-версии и Schedule.java Android-версии).

enum AppConfig {
    static let site = URL(string: "https://oshtu-schedule.onrender.com")!
    // сначала прокси на своём домене (если провайдер блокирует supabase.co), затем напрямую
    static let apiBases = ["https://oshtu-schedule.onrender.com/sb", "https://pzdraaxgzphxennadrlu.supabase.co"]
    static let apiKey = "sb_publishable_DjYWqTHsA02JavCvE3y5Eg_xVNezrf1"
    static let appGroup = "group.kg.esa.oshtu.schedule"
    static let times: [Int: (String, String)] = [
        1: ("08:00", "09:20"), 2: ("09:30", "10:50"), 3: ("11:20", "12:40"),
        4: ("12:50", "14:10"), 5: ("14:20", "15:40"), 6: ("15:50", "17:10"),
    ]
}

struct Lesson: Hashable {
    var subject = ""
    var type = ""
    var teacher = ""
    var room = ""
    var group = ""
    var sub = ""

    var typeShort: String {
        switch type {
        case "лк": return "лк."
        case "пр": return "пр."
        case "лб", "ла": return "лаб."
        case "се": return "сем."
        default: return ""
        }
    }
}

struct Pair: Hashable {
    let n: Int
    let start: String?
    let end: String?
    let lessons: [Lesson]
}

struct UserSettings {
    var kind: String // "group", "teacher", "room"
    var groupId: Int // ID группы, преподавателя или аудитории
    var groupName: String
    var semester: String // "auto", "1", "2"
    var weekFlip: Bool
    var notify: Int // за сколько минут напоминать, 0 — выключено
    var notifyStyle: String // "simple", "melody", "voice"

    /** Правая колонка: аудитория для группы, группа для преподавателя/аудитории. */
    func rightInfo(_ l: Lesson) -> String { kind == "group" ? l.room : l.group }

    func detailLine(_ l: Lesson) -> String {
        var parts = [l.subject + (l.typeShort.isEmpty ? "" : " (\(l.typeShort))")]
        if kind != "group", !l.group.isEmpty { parts.append(l.group) }
        if kind != "teacher", !l.teacher.isEmpty { parts.append(l.teacher) }
        if kind != "room", !l.room.isEmpty { parts.append("ауд. \(l.room)") }
        if !l.sub.isEmpty { parts.append("\(l.sub) подгр.") }
        return parts.joined(separator: " · ")
    }

    var semesterId: Int {
        if semester == "1" { return 1 }
        if semester == "2" { return 2 }
        let m = Calendar.current.component(.month, from: Date()) // 1...12
        return (2...7).contains(m) ? 1 : 2
    }
}

// MARK: - Хранилище (общая App Group для приложения и виджета)

enum Store {
    static var defaults: UserDefaults { UserDefaults(suiteName: AppConfig.appGroup) ?? .standard }

    static var settings: UserSettings? {
        let d = defaults
        let id = d.integer(forKey: "groupId")
        guard id > 0 else { return nil }
        return UserSettings(kind: d.string(forKey: "mode") ?? "group",
                            groupId: id,
                            groupName: d.string(forKey: "groupName") ?? "",
                            semester: d.string(forKey: "semester") ?? "auto",
                            weekFlip: d.bool(forKey: "weekFlip"),
                            notify: d.object(forKey: "notify") as? Int ?? 5,
                            notifyStyle: d.string(forKey: "notifyStyle") ?? "melody")
    }

    private static func int(_ v: Any?) -> Int {
        (v as? NSNumber)?.intValue ?? Int("\(v ?? "")") ?? 0
    }

    /// Настройки приходят из веб-версии внутри приложения (JSON из localStorage).
    static func saveSettings(json: String) {
        guard let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        var kind = obj["mode"] as? String ?? "group"
        if kind != "teacher" && kind != "room" { kind = "group" }
        let id = int(obj["targetId"]) > 0 ? int(obj["targetId"]) : int(obj["groupId"])
        guard id > 0 else { return }
        let name = (obj["targetName"] as? String) ?? (obj["groupName"] as? String) ?? ""
        let sem = obj["semester"].map { "\($0)" } ?? "auto"
        let d = defaults
        if id != d.integer(forKey: "groupId") || kind != (d.string(forKey: "mode") ?? "group")
            || sem != (d.string(forKey: "semester") ?? "auto") {
            d.removeObject(forKey: "cache")
            d.removeObject(forKey: "cacheAt")
        }
        d.set(kind, forKey: "mode")
        d.set(id, forKey: "groupId")
        d.set(name, forKey: "groupName")
        d.set(sem, forKey: "semester")
        d.set((obj["weekFlip"] as? Bool) ?? false, forKey: "weekFlip")
        d.set(obj["notify"] == nil ? 5 : int(obj["notify"]), forKey: "notify")
        d.set(obj["notifyStyle"] as? String ?? "melody", forKey: "notifyStyle")
    }

    static var cache: Data? { defaults.data(forKey: "cache") }
    static var cacheAt: Date? { defaults.object(forKey: "cacheAt") as? Date }

    static func storeCache(_ data: Data) {
        defaults.set(data, forKey: "cache")
        defaults.set(Date(), forKey: "cacheAt")
    }

    // сдвиг дня кнопками ‹ › в виджете (действует только в течение текущего дня)
    static var dayOffset: Int {
        let today = Schedule.dayStamp(Date())
        return defaults.string(forKey: "offsetDay") == today ? defaults.integer(forKey: "offset") : 0
    }

    static func shift(_ delta: Int) {
        let next = delta == 0 ? 0 : dayOffset + delta
        defaults.set(next, forKey: "offset")
        defaults.set(Schedule.dayStamp(Date()), forKey: "offsetDay")
    }
}

// MARK: - Сеть

enum API {
    struct Failure: Error {}

    @discardableResult
    static func fetch() async throws -> Data {
        guard let s = Store.settings else { throw Failure() }
        let body: [String: Any] = [
            "p_kind": s.kind,
            "p_id": s.groupId,
            "p_semester": s.semesterId,
            "p_name": s.groupName.isEmpty ? NSNull() : s.groupName,
            "p_max_age_sec": 300,
        ]
        let payload = try JSONSerialization.data(withJSONObject: body)
        var lastError: Error = Failure()
        for base in AppConfig.apiBases {
            guard let url = URL(string: base + "/rest/v1/rpc/oshtu_timetable") else { continue }
            var req = URLRequest(url: url, timeoutInterval: 15)
            req.httpMethod = "POST"
            req.setValue(AppConfig.apiKey, forHTTPHeaderField: "apikey")
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = payload
            do {
                let (data, resp) = try await URLSession.shared.data(for: req)
                let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
                guard (200..<300).contains(code),
                      let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                      obj["raw"] != nil else { throw Failure() }
                Store.storeCache(data)
                return data
            } catch {
                lastError = error
            }
        }
        throw lastError
    }
}

// MARK: - Разбор и недели

enum Schedule {
    static var calendar: Calendar = {
        var c = Calendar(identifier: .gregorian)
        c.firstWeekday = 2
        c.timeZone = .current
        return c
    }()

    static func startOfDay(_ d: Date) -> Date { calendar.startOfDay(for: d) }
    static func addDays(_ d: Date, _ n: Int) -> Date { calendar.date(byAdding: .day, value: n, to: startOfDay(d))! }

    /// Пн=1 … Вс=7
    static func isoDow(_ d: Date) -> Int {
        let w = calendar.component(.weekday, from: d) // Вс=1
        return w == 1 ? 7 : w - 1
    }

    static func monday(_ d: Date) -> Date { addDays(d, -(isoDow(d) - 1)) }

    static func dayStamp(_ d: Date) -> String {
        let c = calendar.dateComponents([.year, .month, .day], from: d)
        return String(format: "%04d-%02d-%02d", c.year ?? 0, c.month ?? 0, c.day ?? 0)
    }

    static func weekKey(_ d: Date) -> String { dayStamp(monday(d)) }

    /// Неделя 9–14 ноября 2026 на сайте ОшТУ — «верхняя».
    static func isTopWeek(_ d: Date, flip: Bool) -> Bool {
        let anchor = calendar.date(from: DateComponents(year: 2026, month: 11, day: 9))!
        let days = calendar.dateComponents([.day], from: monday(anchor), to: monday(d)).day ?? 0
        let weeks = Int((Double(days) / 7.0).rounded())
        let top = ((weeks % 2) + 2) % 2 == 0
        return flip ? !top : top
    }

    static func minutes(_ hhmm: String) -> Int {
        let p = hhmm.split(separator: ":").compactMap { Int($0) }
        return p.count == 2 ? p[0] * 60 + p[1] : 0
    }

    static func minutesNow(_ d: Date = Date()) -> Int {
        let c = calendar.dateComponents([.hour, .minute], from: d)
        return (c.hour ?? 0) * 60 + (c.minute ?? 0)
    }

    static func duration(_ min: Int) -> String {
        let m = max(0, min), h = m / 60, r = m % 60
        if h > 0 && r > 0 { return "\(h) ч \(r) мин" }
        if h > 0 { return "\(h) ч" }
        return "\(r) мин"
    }

    // MARK: HTML ячейки

    private static func regex(_ p: String) -> NSRegularExpression {
        try! NSRegularExpression(pattern: p, options: [.caseInsensitive])
    }

    private static let brRe = regex("<br\\s*/?>")
    private static let hrRe = regex("<hr[^>]*>")
    private static let tagRe = regex("<[^>]+>")
    private static let spaceRe = regex("\\s+")
    private static let typeLineRe = regex("^(.*?)\\s*\\((лк|пр|лб|лаб|сем)[^)]*\\)\\s*(?:\\[([^\\]]+)\\])?\\s*$")
    private static let subRe = regex("^\\((\\d+)\\)\\s*(.*)$")
    private static let groupTeacherRe = regex("^(\\S*\\d\\S*)\\s+(.+)$")
    private static let typeAnyRe = regex("\\((лк|пр|лб|лаб|сем)[^)]*\\)")
    private static let roomRe = regex("^(.*?)\\s*\\[([^\\]]+)\\]\\s*$")

    private static func replace(_ re: NSRegularExpression, _ s: String, _ with: String) -> String {
        re.stringByReplacingMatches(in: s, range: NSRange(s.startIndex..., in: s), withTemplate: with)
    }

    private static func groups(_ re: NSRegularExpression, _ s: String) -> [String]? {
        guard let m = re.firstMatch(in: s, range: NSRange(s.startIndex..., in: s)) else { return nil }
        return (0..<m.numberOfRanges).map { i in
            Range(m.range(at: i), in: s).map { String(s[$0]) } ?? ""
        }
    }

    private static func decode(_ s: String) -> String {
        s.replacingOccurrences(of: "&nbsp;", with: " ")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&amp;", with: "&")
    }

    /// Формат ячейки зависит от режима:
    /// group:   «(1) Предмет (лк.)» / «Преподаватель [корпус/ауд]»
    /// teacher: «(1) ПИ-1-24 (лк.)  [3/303]» / «Предмет»
    /// room:    «(1) Предмет (лк.)» / «ПИ-1-24 Преподаватель»
    static func parseBlock(_ html: String, kind: String = "group") -> [Lesson] {
        let lines = replace(brRe, html, "\u{1}")
            .components(separatedBy: "\u{1}")
            .map { replace(spaceRe, decode(replace(tagRe, $0, "")), " ").trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }
        let trim: (String) -> String = { $0.trimmingCharacters(in: .whitespaces) }
        var out: [Lesson] = []
        var i = 0
        while i < lines.count {
            let line = lines[i]
            if let g = groups(typeLineRe, line) {
                var head = trim(g[1])
                var l = Lesson(type: String(g[2].lowercased().prefix(2)), room: trim(g[3]))
                if let s = groups(subRe, head) {
                    l.sub = s[1]
                    head = trim(s[2])
                }
                let next: String? = (i + 1 < lines.count && groups(typeAnyRe, lines[i + 1]) == nil) ? lines[i + 1] : nil
                switch kind {
                case "teacher":
                    l.group = head
                    if let n = next { l.subject = n; i += 1 }
                case "room":
                    l.subject = head
                    if let n = next {
                        if let gt = groups(groupTeacherRe, n) { l.group = gt[1]; l.teacher = gt[2] } else { l.teacher = n }
                        i += 1
                    }
                default:
                    l.subject = head
                    if let n = next {
                        if let r = groups(roomRe, n) { l.teacher = trim(r[1]); l.room = trim(r[2]) } else { l.teacher = n }
                        i += 1
                    }
                }
                if l.subject.isEmpty { l.subject = l.group.isEmpty ? "Занятие" : l.group }
                out.append(l)
            } else if let r = groups(roomRe, line), let last = out.last, last.teacher.isEmpty {
                out[out.count - 1].teacher = r[1].trimmingCharacters(in: .whitespaces)
                out[out.count - 1].room = r[2].trimmingCharacters(in: .whitespaces)
            } else {
                out.append(Lesson(subject: line))
            }
            i += 1
        }
        return out
    }

    static func parseCell(_ html: String, kind: String = "group") -> (top: [Lesson], bottom: [Lesson])? {
        let bare = replace(regex("<[^>]+>|\\s|&nbsp;"), html, "")
        if bare.isEmpty { return nil }
        let marked = replace(hrRe, html, "\u{2}")
        let parts = marked.components(separatedBy: "\u{2}")
        if parts.count == 1 {
            let l = parseBlock(parts[0], kind: kind)
            return l.isEmpty ? nil : (l, l)
        }
        let top = parseBlock(parts[0], kind: kind)
        let bottom = parseBlock(parts.dropFirst().joined(), kind: kind)
        return top.isEmpty && bottom.isEmpty ? nil : (top, bottom)
    }

    // MARK: Версия расписания нужной недели

    static func rawFor(_ data: [String: Any], weekKey key: String) -> [[String: Any]] {
        let weeks = (data["weeks"] as? [[String: Any]] ?? [])
            .sorted { ($0["week_start"] as? String ?? "") < ($1["week_start"] as? String ?? "") }
        let pick = weeks.first { $0["week_start"] as? String == key }
            ?? weeks.last { ($0["week_start"] as? String ?? "") < key }
            ?? weeks.first
        if let raw = pick?["raw"] as? [[String: Any]] { return raw }
        return data["raw"] as? [[String: Any]] ?? []
    }

    static func cachedData() -> [String: Any]? {
        guard let d = Store.cache else { return nil }
        return try? JSONSerialization.jsonObject(with: d) as? [String: Any]
    }

    static func lessons(on day: Date, data: [String: Any]?, flip: Bool) -> [Pair] {
        guard let data else { return [] }
        let wd = isoDow(day)
        guard wd <= 6 else { return [] }
        let top = isTopWeek(day, flip: flip)
        let kind = Store.settings?.kind ?? "group"
        var out: [Pair] = []
        for row in rawFor(data, weekKey: weekKey(day)) {
            guard let html = row["WeekDay\(wd)"] as? String, let cell = parseCell(html, kind: kind) else { continue }
            let lessons = top ? cell.top : cell.bottom
            guard !lessons.isEmpty else { continue }
            let n = (row["PairNumber"] as? NSNumber)?.intValue ?? 0
            let t = AppConfig.times[n]
            out.append(Pair(n: n, start: t?.0, end: t?.1, lessons: lessons))
        }
        return out.sorted { $0.n < $1.n }
    }

    /// Сегодня; после окончания пар и в воскресенье — следующий учебный день.
    static func baseDay(data: [String: Any]?, flip: Bool, now: Date = Date()) -> Date {
        var d = startOfDay(now)
        if isoDow(d) == 7 { return addDays(d, 1) }
        let list = lessons(on: d, data: data, flip: flip)
        let lastEnd = list.compactMap { $0.end.map(minutes) }.max() ?? -1
        let t = minutesNow(now)
        let over = (!list.isEmpty && lastEnd > 0 && t >= lastEnd) || (list.isEmpty && data != nil && t >= 17 * 60)
        if over {
            d = addDays(d, 1)
            if isoDow(d) == 7 { d = addDays(d, 1) }
        }
        return d
    }

    static func shownDay(data: [String: Any]?, flip: Bool, offset: Int, now: Date = Date()) -> Date {
        var d = baseDay(data: data, flip: flip, now: now)
        let step = offset > 0 ? 1 : -1
        for _ in 0..<abs(offset) {
            d = addDays(d, step)
            if isoDow(d) == 7 { d = addDays(d, step) }
        }
        return d
    }
}
