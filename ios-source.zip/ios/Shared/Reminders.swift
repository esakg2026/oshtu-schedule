import Foundation
import UserNotifications

/// Напоминания перед парой. Стили: простой (системный звук), обычный (своя мелодия oshtu_chime.wav),
/// голосовой (мелодия + голос, когда приложение открыто; в фоне iOS не разрешает приложениям говорить).
/// iOS позволяет заранее запланировать до 64 локальных уведомлений — планируем пары на 7 дней вперёд.
enum Reminders {
    static let prefix = "oshtu.lesson."
    static let chime = UNNotificationSound(named: UNNotificationSoundName("oshtu_chime.wav"))

    static func sound(for style: String) -> UNNotificationSound {
        style == "simple" ? .default : chime
    }

    static func requestPermission(_ done: ((Bool) -> Void)? = nil) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
            done?(ok)
        }
    }

    // MARK: текст для голоса

    private static let ord = [
        ["", "первая", "вторая", "третья", "четвёртая", "пятая", "шестая", "седьмая"],
        ["", "биринчи", "экинчи", "үчүнчү", "төртүнчү", "бешинчи", "алтынчы", "жетинчи"],
        ["", "first", "second", "third", "fourth", "fifth", "sixth", "seventh"],
    ]

    private static func minutesWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "минута" }
        if (2...4).contains(m10) && (m100 < 12 || m100 > 14) { return "минуты" }
        return "минут"
    }

    private static func typeWord(_ t: String, _ lang: String) -> String {
        switch t {
        case "лк": return lang == "en" ? "lecture" : "лекция"
        case "пр": return lang == "en" ? "practical" : "практика"
        case "лб", "ла": return lang == "en" ? "lab" : lang == "ky" ? "лабораториялык иш" : "лабораторная работа"
        case "се": return lang == "en" ? "seminar" : "семинар"
        default: return ""
        }
    }

    /// Текст голоса на выбранном языке (та же логика, что speechText в core.js и Schedule.java).
    static func speechText(_ s: UserSettings, _ p: Pair, _ min: Int, lang: String = L10n.lang) -> String {
        let l = p.lessons[0]
        var teacher = l.teacher
        while teacher.hasSuffix(".") { teacher.removeLast() }
        let tw = typeWord(l.type, lang)
        let rp = l.room.split(separator: "/", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
        let b: String? = rp.count == 2 ? rp[0] : nil
        let r = rp.count == 2 ? rp[1] : l.room.trimmingCharacters(in: .whitespaces)
        let hasOrd = p.n > 0 && p.n < ord[0].count
        var parts: [String] = []

        switch lang {
        case "ky":
            let o = hasOrd ? "\(ord[1][p.n]) пара" : "\(p.n)-пара"
            if s.kind == "room" { parts.append("\(min) мүнөттөн кийин бул аудиторияда \(o) башталат.") }
            else { parts.append("Сабакка \(min) мүнөт калды. \(o.prefix(1).uppercased() + o.dropFirst()) башталат.") }
            parts.append("\(l.subject)\(tw.isEmpty ? "" : ", " + tw).")
            if s.kind != "room", !l.room.isEmpty {
                parts.append("Сабак \(b.map { "\($0)-корпустун \(r)-аудиториясында" } ?? "\(r)-аудиторияда") өтөт.")
            }
            if s.kind != "group", !l.group.isEmpty { parts.append("\(l.group) тобу\(l.sub.isEmpty ? "" : ", \(l.sub)-топчо").") }
            if s.kind != "teacher", !teacher.isEmpty { parts.append("Сабакты \(teacher) өткөрөт.") }
            if s.kind == "group", !l.sub.isEmpty { parts.append("\(l.sub)-топчо үчүн.") }
        case "en":
            let o = hasOrd ? "the \(ord[2][p.n]) period" : "period \(p.n)"
            let mins = "\(min) \(min == 1 ? "minute" : "minutes")"
            if s.kind == "room" { parts.append("In \(mins), \(o) starts in this room.") }
            else { parts.append("Your class starts in \(mins). It's \(o).") }
            parts.append("\(l.subject)\(tw.isEmpty ? "" : ", " + tw).")
            if s.kind != "room", !l.room.isEmpty { parts.append("Room: \(b.map { "building \($0), room \(r)" } ?? "room \(r)").") }
            if s.kind != "group", !l.group.isEmpty { parts.append("Group \(l.group)\(l.sub.isEmpty ? "" : ", subgroup \(l.sub)").") }
            if s.kind != "teacher", !teacher.isEmpty { parts.append("Teacher: \(teacher).") }
            if s.kind == "group", !l.sub.isEmpty { parts.append("For subgroup \(l.sub).") }
        default:
            let o = hasOrd ? "\(ord[0][p.n]) пара" : "\(p.n)-я пара"
            let mw = minutesWord(min)
            if s.kind == "room" {
                parts.append("Через \(min) \(mw == "минута" ? "минуту" : mw) в этой аудитории начнётся \(o).")
            } else {
                parts.append("До занятия \(mw == "минута" ? "осталась" : "осталось") \(min) \(mw). Начинается \(o).")
            }
            parts.append("\(l.subject)\(tw.isEmpty ? "" : ", " + tw).")
            if s.kind != "room", !l.room.isEmpty {
                parts.append("Занятие пройдёт: \(b.map { "корпус \($0), аудитория \(r)" } ?? "аудитория \(r)").")
            }
            if s.kind != "group", !l.group.isEmpty { parts.append("У группы \(l.group)\(l.sub.isEmpty ? "" : ", \(l.sub) подгруппа").") }
            if s.kind != "teacher", !teacher.isEmpty { parts.append("Проводит \(teacher).") }
            if s.kind == "group", !l.sub.isEmpty { parts.append("Для \(l.sub) подгруппы.") }
        }
        return parts.joined(separator: " ")
    }

    // MARK: планирование

    static func reschedule() {
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { pending in
            let ours = pending.map(\.identifier).filter { $0.hasPrefix(prefix) }
            center.removePendingNotificationRequests(withIdentifiers: ours)

            guard let s = Store.settings, s.notify > 0, let data = Schedule.cachedData() else { return }
            center.getNotificationSettings { st in
                guard st.authorizationStatus == .authorized || st.authorizationStatus == .provisional else { return }
                let now = Date()
                var count = 0
                for i in 0..<7 {
                    let day = Schedule.addDays(now, i)
                    for p in Schedule.lessons(on: day, data: data, flip: s.weekFlip) {
                        guard let start = p.start, count < 60 else { continue }
                        let at = day.addingTimeInterval(TimeInterval(Schedule.minutes(start) * 60))
                        let fire = at.addingTimeInterval(TimeInterval(-s.notify * 60))
                        guard fire > now.addingTimeInterval(5) else { continue }
                        let content = UNMutableNotificationContent()
                        content.title = L10n.f("remTitle", s.notify, p.n, start)
                        content.body = s.detailLine(p.lessons[0])
                        content.sound = sound(for: s.notifyStyle)
                        content.userInfo = ["speech": speechText(s, p, s.notify), "lang": L10n.lang]
                        if #available(iOS 15.0, *) { content.interruptionLevel = .timeSensitive }
                        let comps = Schedule.calendar.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
                        let id = prefix + "\(Int(at.timeIntervalSince1970))"
                        center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
                        count += 1
                    }
                }
            }
        }
    }

    /// Пробное напоминание через 2 секунды в выбранном стиле.
    static func test(title: String?, body: String?, speech: String?) {
        requestPermission { ok in
            guard ok else { return }
            let style = Store.settings?.notifyStyle ?? "melody"
            let content = UNMutableNotificationContent()
            content.title = title ?? L10n.f("remTitle", 5, 4, "12:50")
            content.body = body ?? L10n.t("testBody")
            content.sound = sound(for: style)
            content.userInfo = ["speech": speech ?? L10n.t("testSpeech"), "lang": L10n.lang]
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
            UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "oshtu.test", content: content, trigger: trigger))
        }
    }
}
