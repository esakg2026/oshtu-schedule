import Foundation
import UserNotifications

/// Напоминания перед парой со своей мелодией (oshtu_chime.wav в бандле приложения).
/// iOS позволяет заранее запланировать до 64 локальных уведомлений — планируем пары на 7 дней вперёд
/// и пересчитываем при каждом открытии приложения и обновлении виджета.
enum Reminders {
    static let prefix = "oshtu.lesson."
    static let sound = UNNotificationSound(named: UNNotificationSoundName("oshtu_chime.wav"))

    static func requestPermission(_ done: ((Bool) -> Void)? = nil) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
            done?(ok)
        }
    }

    static func reschedule() {
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { pending in
            let ours = pending.map(\.identifier).filter { $0.hasPrefix(prefix) }
            center.removePendingNotificationRequests(withIdentifiers: ours)

            guard let s = Store.settings, s.notify > 0, let data = Schedule.cachedData() else { return }
            center.getNotificationSettings { st in
                guard st.authorizationStatus == .authorized || st.authorizationStatus == .provisional else { return }
                let now = Date()
                var count = 0
                for i in 0..<7 {
                    let day = Schedule.addDays(now, i)
                    for p in Schedule.lessons(on: day, data: data, flip: s.weekFlip) {
                        guard let start = p.start, count < 60 else { continue }
                        let at = day.addingTimeInterval(TimeInterval(Schedule.minutes(start) * 60))
                        let fire = at.addingTimeInterval(TimeInterval(-s.notify * 60))
                        guard fire > now.addingTimeInterval(5) else { continue }
                        let content = UNMutableNotificationContent()
                        content.title = "Через \(s.notify) мин — \(p.n)-я пара (\(start))"
                        content.body = s.detailLine(p.lessons[0])
                        content.sound = sound
                        if #available(iOS 15.0, *) { content.interruptionLevel = .timeSensitive }
                        let comps = Schedule.calendar.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
                        let id = prefix + "\(Int(at.timeIntervalSince1970))"
                        center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
                        count += 1
                    }
                }
            }
        }
    }

    /// Пробное напоминание через 2 секунды — чтобы услышать мелодию.
    static func test() {
        requestPermission { ok in
            guard ok else { return }
            let content = UNMutableNotificationContent()
            content.title = "Через 5 мин — 4-я пара (12:50)"
            content.body = "Так будет звучать напоминание о паре"
            content.sound = sound
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
            UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "oshtu.test", content: content, trigger: trigger))
        }
    }
}
