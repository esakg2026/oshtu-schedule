import Foundation
import UserNotifications

/// Напоминания перед парой. Стили: простой (системный звук), обычный (своя мелодия oshtu_chime.wav),
/// голосовой (мелодия + голос, когда приложение открыто; в фоне iOS не разрешает приложениям говорить).
/// iOS позволяет заранее запланировать до 64 локальных уведомлений — планируем пары на 7 дней вперёд.
enum Reminders {
    static let prefix = "oshtu.lesson."
    static let chime = UNNotificationSound(named: UNNotificationSoundName("oshtu_chime.wav"))

    static func sound(for style: String) -> UNNotificationSound {
        style == "simple" ? .default : chime
    }

    static func requestPermission(_ done: ((Bool) -> Void)? = nil) {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { ok, _ in
            done?(ok)
        }
    }

    // MARK: текст для голоса

    private static let ord = ["", "первая", "вторая", "третья", "четвёртая", "пятая", "шестая", "седьмая"]

    private static func minutesWord(_ n: Int) -> String {
        let m10 = n % 10, m100 = n % 100
        if m10 == 1 && m100 != 11 { return "минута" }
        if (2...4).contains(m10) && (m100 < 12 || m100 > 14) { return "минуты" }
        return "минут"
    }

    private static func typeWord(_ t: String) -> String {
        switch t {
        case "лк": return "лекция"
        case "пр": return "практика"
        case "лб", "ла": return "лабораторная работа"
        case "се": return "семинар"
        default: return ""
        }
    }

    private static func roomWords(_ room: String) -> String {
        let p = room.split(separator: "/", maxSplits: 1).map { $0.trimmingCharacters(in: .whitespaces) }
        return p.count == 2 ? "корпус \(p[0]), аудитория \(p[1])" : "аудитория \(room)"
    }

    static func speechText(_ s: UserSettings, _ p: Pair, _ min: Int) -> String {
        let l = p.lessons[0]
        let o = p.n > 0 && p.n < ord.count ? "\(ord[p.n]) пара" : "\(p.n)-я пара"
        let mw = minutesWord(min)
        var parts: [String] = []
        if s.kind == "room" {
            parts.append("Через \(min) \(mw == "минута" ? "минуту" : mw) в этой аудитории начнётся \(o).")
        } else {
            parts.append("До занятия \(mw == "минута" ? "осталась" : "осталось") \(min) \(mw). Начинается \(o).")
        }
        let tw = typeWord(l.type)
        parts.append("\(l.subject)\(tw.isEmpty ? "" : ", " + tw).")
        if s.kind != "room", !l.room.isEmpty { parts.append("Занятие пройдёт: \(roomWords(l.room)).") }
        if s.kind != "group", !l.group.isEmpty { parts.append("У группы \(l.group)\(l.sub.isEmpty ? "" : ", \(l.sub) подгруппа").") }
        if s.kind != "teacher", !l.teacher.isEmpty {
            var t = l.teacher
            while t.hasSuffix(".") { t.removeLast() }
            parts.append("Проводит \(t).")
        }
        if s.kind == "group", !l.sub.isEmpty { parts.append("Для \(l.sub) подгруппы.") }
        return parts.joined(separator: " ")
    }

    // MARK: планирование

    static func reschedule() {
        let center = UNUserNotificationCenter.current()
        center.getPendingNotificationRequests { pending in
            let ours = pending.map(\.identifier).filter { $0.hasPrefix(prefix) }
            center.removePendingNotificationRequests(withIdentifiers: ours)

            guard let s = Store.settings, s.notify > 0, let data = Schedule.cachedData() else { return }
            center.getNotificationSettings { st in
                guard st.authorizationStatus == .authorized || st.authorizationStatus == .provisional else { return }
                let now = Date()
                var count = 0
                for i in 0..<7 {
                    let day = Schedule.addDays(now, i)
                    for p in Schedule.lessons(on: day, data: data, flip: s.weekFlip) {
                        guard let start = p.start, count < 60 else { continue }
                        let at = day.addingTimeInterval(TimeInterval(Schedule.minutes(start) * 60))
                        let fire = at.addingTimeInterval(TimeInterval(-s.notify * 60))
                        guard fire > now.addingTimeInterval(5) else { continue }
                        let content = UNMutableNotificationContent()
                        content.title = "Через \(s.notify) мин — \(p.n)-я пара (\(start))"
                        content.body = s.detailLine(p.lessons[0])
                        content.sound = sound(for: s.notifyStyle)
                        content.userInfo = ["speech": speechText(s, p, s.notify)]
                        if #available(iOS 15.0, *) { content.interruptionLevel = .timeSensitive }
                        let comps = Schedule.calendar.dateComponents([.year, .month, .day, .hour, .minute], from: fire)
                        let trigger = UNCalendarNotificationTrigger(dateMatching: comps, repeats: false)
                        let id = prefix + "\(Int(at.timeIntervalSince1970))"
                        center.add(UNNotificationRequest(identifier: id, content: content, trigger: trigger))
                        count += 1
                    }
                }
            }
        }
    }

    /// Пробное напоминание через 2 секунды в выбранном стиле.
    static func test(title: String?, body: String?, speech: String?) {
        requestPermission { ok in
            guard ok else { return }
            let style = Store.settings?.notifyStyle ?? "melody"
            let content = UNMutableNotificationContent()
            content.title = title ?? "Через 5 мин — 4-я пара (12:50)"
            content.body = body ?? "Так будет звучать напоминание о паре"
            content.sound = sound(for: style)
            content.userInfo = ["speech": speech ?? "До занятия осталось 5 минут. Так будет звучать голосовое напоминание."]
            let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 2, repeats: false)
            UNUserNotificationCenter.current().add(UNNotificationRequest(identifier: "oshtu.test", content: content, trigger: trigger))
        }
    }
}
