import Foundation

/// Тексты виджета, уведомлений и голоса на трёх языках (ru / ky / en) — язык выбирается в приложении.
enum L10n {
    static var lang: String {
        let l = Store.defaults.string(forKey: "lang") ?? "ru"
        return ["ru", "ky", "en"].contains(l) ? l : "ru"
    }

    private static var idx: Int { lang == "ky" ? 1 : lang == "en" ? 2 : 0 }

    private static let table: [String: [String]] = [
        "app": ["Расписание ОшТУ", "ОшТУ жадыбалы", "OshTU Schedule"],
        "schedule": ["Расписание", "Жадыбал", "Schedule"],
        "today": ["Сегодня", "Бүгүн", "Today"],
        "tomorrow": ["Завтра", "Эртең", "Tomorrow"],
        "yesterday": ["Вчера", "Кечээ", "Yesterday"],
        "top": ["верхняя", "үстүңкү", "top"],
        "bottom": ["нижняя", "астыңкы", "bottom"],
        "first": ["Первая пара через %@", "Биринчи пара %@ кийин", "First class in %@"],
        "next": ["Дальше %d-я через %@", "%d-пара %@ кийин", "Period %d in %@"],
        "now": ["Сейчас %d-я · ещё %@", "Азыр %d-пара · дагы %@", "Period %d now · %@ left"],
        "over": ["Пары на сегодня закончились", "Бүгүнкү сабактар бүттү", "Classes are over for today"],
        "none": ["Пар нет", "Сабак жок", "No classes"],
        "noneLow": ["пар нет", "сабак жок", "no classes"],
        "pairs": ["пар(ы)", "пара", "classes"],
        "dayOff": ["Выходной", "Дем алыш", "Day off"],
        "more": ["ещё %d…", "дагы %d…", "%d more…"],
        "open": ["Открой приложение и выбери расписание", "Тиркемени ачып, жадыбалды тандаңыз", "Open the app and choose a schedule"],
        "offline": ["нет сети, копия", "тармак жок, көчүрмө", "offline copy"],
        "updated": ["обновлено", "жаңыланды", "updated"],
        "room": ["ауд.", "ауд.", "room"],
        "sub": ["%@ подгр.", "%@-топчо", "subgr. %@"],
        "h": ["ч", "саат", "h"],
        "min": ["мин", "мүн", "min"],
        "remTitle": ["Через %d мин — %d-я пара (%@)", "%d мүнөттөн кийин — %d-пара (%@)", "In %d min — period %d (%@)"],
        "testBody": ["Так будет звучать напоминание о паре", "Сабак тууралуу эскертүү ушундай угулат", "This is how a class reminder sounds"],
        "testSpeech": ["До занятия осталось 5 минут. Так будет звучать голосовое напоминание.",
                       "Сабакка 5 мүнөт калды. Үн менен эскертүү ушундай угулат.",
                       "Your class starts in 5 minutes. This is how a voice reminder sounds."],
        "lec": ["лк.", "лк.", "lec."], "prac": ["пр.", "пр.", "pr."], "lab": ["лаб.", "лаб.", "lab"], "sem": ["сем.", "сем.", "sem."],
    ]

    static func t(_ key: String) -> String { table[key]?[idx] ?? key }

    static func f(_ key: String, _ args: CVarArg...) -> String {
        String(format: t(key), locale: Locale(identifier: "en_US_POSIX"), arguments: args)
    }

    private static let wd = [
        ["", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"],
        ["", "дүйшөмбү", "шейшемби", "шаршемби", "бейшемби", "жума", "ишемби", "жекшемби"],
        ["", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    ]
    private static let wds = [
        ["", "пн", "вт", "ср", "чт", "пт", "сб", "вс"],
        ["", "дш", "шш", "шр", "бш", "жм", "иш", "жк"],
        ["", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    ]
    private static let mon = [
        ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"],
        ["янв", "фев", "мар", "апр", "май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"],
        ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    ]

    static func weekday(_ d: Date) -> String {
        let s = wd[idx][Schedule.isoDow(d)]
        return s.prefix(1).uppercased() + s.dropFirst()
    }

    /// «пн, 16 ноя» / «дш, 16-ноя» / «Mon, 16 Nov»
    static func shortDate(_ d: Date) -> String {
        let day = Schedule.calendar.component(.day, from: d)
        let m = Schedule.calendar.component(.month, from: d) - 1
        return "\(wds[idx][Schedule.isoDow(d)]), \(day)\(idx == 1 ? "-" : " ")\(mon[idx][m])"
    }

    static func typeShort(_ t: String) -> String {
        switch t {
        case "лк": return self.t("lec")
        case "пр": return self.t("prac")
        case "лб", "ла": return self.t("lab")
        case "се": return self.t("sem")
        default: return ""
        }
    }

    /// Куски текста для голосов: в английском русские названия и ФИО читает русский голос.
    static func segments(_ text: String, lang: String) -> [(lang: String, text: String)] {
        guard lang == "en" else { return [(lang, text)] }
        var out: [(lang: String, text: String)] = []
        let cyr = CharacterSet(charactersIn: "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюяӨөҮүҢң")
        let lat = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz")
        var word = ""
        func flush() {
            guard !word.isEmpty else { return }
            let k: String? = word.unicodeScalars.contains(where: { cyr.contains($0) }) ? "ru"
                : word.unicodeScalars.contains(where: { lat.contains($0) }) ? "en" : nil
            if out.isEmpty { out.append((k ?? "en", word)) }
            else if let k, k != out[out.count - 1].lang { out.append((k, word)) }
            else { out[out.count - 1].text += word }
            word = ""
        }
        for ch in text {
            word.append(ch)
            if ch == " " { flush() }
        }
        flush()
        return out.filter { !$0.text.trimmingCharacters(in: .whitespaces).isEmpty }
    }
}
