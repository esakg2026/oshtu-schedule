import AppIntents
import SwiftUI
import WidgetKit

// MARK: - Данные для виджета

struct ScheduleEntry: TimelineEntry {
    let date: Date
    let day: Date
    let title: String
    let subtitle: String
    let pairs: [Pair]
    let status: String?
    let groupName: String
    let updated: Date?
    let offline: Bool
    let needsSetup: Bool
    let isToday: Bool
}

enum EntryBuilder {
    static let ru = Locale(identifier: "ru_RU")

    static func make(at now: Date, offline: Bool) -> ScheduleEntry {
        guard let s = Store.settings else {
            return ScheduleEntry(date: now, day: now, title: "Расписание", subtitle: "", pairs: [], status: nil,
                                 groupName: "", updated: nil, offline: false, needsSetup: true, isToday: true)
        }
        let data = Schedule.cachedData()
        let day = Schedule.shownDay(data: data, flip: s.weekFlip, offset: Store.dayOffset, now: now)
        let today = Schedule.startOfDay(now)
        let diff = Schedule.calendar.dateComponents([.day], from: today, to: day).day ?? 0
        let title: String
        switch diff {
        case 0: title = "Сегодня"
        case 1: title = "Завтра"
        case -1: title = "Вчера"
        default: title = format(day, "EEEE").capitalized(with: ru)
        }
        let week = Schedule.isTopWeek(day, flip: s.weekFlip) ? "верхняя" : "нижняя"
        let pairs = Schedule.lessons(on: day, data: data, flip: s.weekFlip)
        return ScheduleEntry(date: now, day: day, title: title, subtitle: "\(format(day, "EE, d MMM")) · \(week)",
                             pairs: pairs, status: status(pairs, isToday: diff == 0, now: now),
                             groupName: s.groupName, updated: Store.cacheAt, offline: offline,
                             needsSetup: false, isToday: diff == 0)
    }

    static func format(_ d: Date, _ f: String) -> String {
        let df = DateFormatter()
        df.locale = ru
        df.dateFormat = f
        return df.string(from: d)
    }

    static func status(_ pairs: [Pair], isToday: Bool, now: Date) -> String? {
        guard isToday else { return nil }
        let t = Schedule.minutesNow(now)
        for (i, p) in pairs.enumerated() {
            guard let st = p.start, let en = p.end else { continue }
            let s = Schedule.minutes(st), e = Schedule.minutes(en)
            if t < s { return "\(i == 0 ? "Первая пара" : "Дальше \(p.n)-я") через \(Schedule.duration(s - t))" }
            if t < e { return "Сейчас \(p.n)-я · ещё \(Schedule.duration(e - t))" }
        }
        return pairs.isEmpty ? nil : "Пары на сегодня закончились"
    }

    /// Моменты начала и конца пар сегодня — чтобы подсветка менялась без интернета.
    static func boundaries(after now: Date) -> [Date] {
        guard let s = Store.settings else { return [] }
        let today = Schedule.startOfDay(now)
        let pairs = Schedule.lessons(on: today, data: Schedule.cachedData(), flip: s.weekFlip)
        var out: [Date] = []
        for p in pairs {
            for t in [p.start, p.end].compactMap({ $0 }) {
                let d = today.addingTimeInterval(TimeInterval(Schedule.minutes(t) * 60 + 5))
                if d > now { out.append(d) }
            }
        }
        // каждые 10 минут обновляем «ещё N мин»
        var tick = now.addingTimeInterval(600)
        while tick < now.addingTimeInterval(3600) {
            out.append(tick)
            tick = tick.addingTimeInterval(600)
        }
        return Array(Set(out)).sorted()
    }
}

struct Provider: TimelineProvider {
    func placeholder(in context: Context) -> ScheduleEntry {
        let sample = [
            Pair(n: 4, start: "12:50", end: "14:10", lessons: [Lesson(subject: "Аналитика больших данных", type: "лк", room: "3/303")]),
            Pair(n: 5, start: "14:20", end: "15:40", lessons: [Lesson(subject: "Машинное обучение", type: "пр", room: "3/303")]),
        ]
        return ScheduleEntry(date: Date(), day: Date(), title: "Сегодня", subtitle: "пн, 16 нояб · нижняя", pairs: sample,
                             status: "Сейчас 4-я · ещё 40 мин", groupName: "ПИ-1-23", updated: Date(),
                             offline: false, needsSetup: false, isToday: true)
    }

    func getSnapshot(in context: Context, completion: @escaping (ScheduleEntry) -> Void) {
        completion(Store.cache == nil ? placeholder(in: context) : EntryBuilder.make(at: Date(), offline: false))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<ScheduleEntry>) -> Void) {
        Task {
            var offline = false
            if Store.settings != nil {
                do { try await API.fetch() } catch { offline = true }
                Reminders.reschedule()
            }
            let now = Date()
            var entries = [EntryBuilder.make(at: now, offline: offline)]
            for d in EntryBuilder.boundaries(after: now) {
                entries.append(EntryBuilder.make(at: d, offline: offline))
            }
            completion(Timeline(entries: entries, policy: .after(now.addingTimeInterval(30 * 60))))
        }
    }
}

// MARK: - Кнопки ‹ › (iOS 17+)

@available(iOS 17.0, *)
struct ShiftDayIntent: AppIntent {
    static var title: LocalizedStringResource = "Сменить день"
    static var isDiscoverable: Bool = false

    @Parameter(title: "Сдвиг")
    var delta: Int

    init() { delta = 0 }
    init(delta: Int) { self.delta = delta }

    func perform() async throws -> some IntentResult {
        Store.shift(delta)
        return .result()
    }
}

// MARK: - Внешний вид

enum Palette {
    static let bg = LinearGradient(colors: [Color(hex: 0x161927), Color(hex: 0x1E2240)], startPoint: .topLeading, endPoint: .bottomTrailing)
    static let text = Color(hex: 0xEEF0FA)
    static let muted = Color(hex: 0x8D92AB)
    static let accent = Color(hex: 0x9D9DFF)
    static let past = Color(hex: 0x5A5F78)
    static let now = LinearGradient(colors: [Color(hex: 0x5B5BF6), Color(hex: 0x8B5CF6)], startPoint: .leading, endPoint: .trailing)
    static let status = Color(hex: 0x2A2C5A)
}

extension Color {
    init(hex: UInt32) {
        self.init(red: Double((hex >> 16) & 0xFF) / 255, green: Double((hex >> 8) & 0xFF) / 255, blue: Double(hex & 0xFF) / 255)
    }
}

struct NavButton: View {
    let symbol: String
    let delta: Int

    var body: some View {
        if #available(iOS 17.0, *) {
            Button(intent: ShiftDayIntent(delta: delta)) {
                Image(systemName: symbol)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(Palette.text)
                    .frame(width: 30, height: 26)
                    .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 9))
            }
            .buttonStyle(.plain)
        }
    }
}

struct PairRow: View {
    let pair: Pair
    let entry: ScheduleEntry
    let compact: Bool

    var body: some View {
        let t = Schedule.minutesNow(entry.date)
        let past = entry.isToday && (pair.end.map { t >= Schedule.minutes($0) } ?? false)
        let cur = entry.isToday && !past && (pair.start.map { t >= Schedule.minutes($0) } ?? false)
        let l = pair.lessons[0]
        let name = compact ? l.subject
            : l.subject + (l.typeShort.isEmpty ? "" : " (\(l.typeShort))") + (pair.lessons.count > 1 ? " +\(pair.lessons.count - 1)" : "")
        HStack(spacing: 6) {
            Text("\(pair.n)").font(.system(size: 13, weight: .heavy))
                .foregroundStyle(cur ? Palette.text : past ? Palette.past : Palette.accent)
                .frame(width: 14, alignment: .leading)
            if !compact {
                Text(pair.start ?? "").font(.system(size: 11)).monospacedDigit()
                    .foregroundStyle(cur ? Palette.text : past ? Palette.past : Palette.muted)
                    .frame(width: 36, alignment: .leading)
            }
            Text(name).font(.system(size: compact ? 12 : 13, weight: .semibold))
                .foregroundStyle(past ? Palette.past : Palette.text).lineLimit(1)
            Spacer(minLength: 4)
            let right = Store.settings?.rightInfo(l) ?? l.room
            if !compact && !right.isEmpty {
                Text(right).font(.system(size: 11)).foregroundStyle(cur ? Palette.text : past ? Palette.past : Palette.muted)
            }
        }
        .padding(.vertical, 3).padding(.horizontal, 6)
        .background {
            if cur { RoundedRectangle(cornerRadius: 8).fill(Palette.now) }
        }
    }
}

struct ScheduleWidgetView: View {
    @Environment(\.widgetFamily) var family
    let entry: ScheduleEntry

    var body: some View {
        switch family {
        case .accessoryInline:
            inline
        case .accessoryRectangular:
            rectangular
        default:
            home.widgetBackground(Palette.bg)
        }
    }

    private var inline: some View {
        let p = entry.pairs.first { p in
            guard entry.isToday, let e = p.end else { return true }
            return Schedule.minutesNow(entry.date) < Schedule.minutes(e)
        }
        return Text(p.map { "\($0.n) · \($0.start ?? "") \($0.lessons[0].subject)" } ?? "Пар нет")
    }

    private var rectangular: some View {
        VStack(alignment: .leading, spacing: 1) {
            Text(entry.status ?? "\(entry.title): \(entry.pairs.isEmpty ? "пар нет" : "\(entry.pairs.count) пар(ы)")")
                .font(.system(size: 13, weight: .bold)).lineLimit(1)
            ForEach(entry.pairs.prefix(2), id: \.self) { p in
                Text("\(p.n) · \(p.start ?? "") \(p.lessons[0].subject)").font(.system(size: 12)).lineLimit(1)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .widgetBackground(Color.clear)
    }

    private var home: some View {
        let small = family == .systemSmall
        let maxRows = family == .systemLarge || family == .systemExtraLarge ? 6 : 3
        return VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .center, spacing: 6) {
                VStack(alignment: .leading, spacing: 1) {
                    Text(entry.title).font(.system(size: small ? 15 : 18, weight: .bold)).foregroundStyle(Palette.text)
                    if !small {
                        Text(entry.subtitle).font(.system(size: 11)).foregroundStyle(Palette.muted).lineLimit(1)
                    }
                }
                Spacer(minLength: 0)
                if !small && !entry.needsSetup {
                    NavButton(symbol: "chevron.left", delta: -1)
                    NavButton(symbol: "chevron.right", delta: 1)
                }
            }
            if let st = entry.status, !small {
                Text(st).font(.system(size: 11, weight: .medium)).foregroundStyle(Palette.text).lineLimit(1)
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(Palette.status, in: RoundedRectangle(cornerRadius: 8))
                    .padding(.top, 6)
            }
            Spacer(minLength: 6).frame(maxHeight: 8)
            if entry.needsSetup {
                Text("Открой приложение и выбери расписание").font(.system(size: 13, weight: .medium)).foregroundStyle(Palette.muted)
            } else if entry.pairs.isEmpty {
                Text(Schedule.isoDow(entry.day) == 7 ? "Выходной" : "Пар нет 🎉").font(.system(size: 15, weight: .medium)).foregroundStyle(Palette.muted)
            } else {
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(entry.pairs.prefix(maxRows), id: \.self) { p in
                        PairRow(pair: p, entry: entry, compact: small)
                    }
                    if entry.pairs.count > maxRows {
                        Text("ещё \(entry.pairs.count - maxRows)…").font(.system(size: 11)).foregroundStyle(Palette.muted)
                    }
                }
            }
            Spacer(minLength: 0)
            if !entry.needsSetup {
                Text(footer).font(.system(size: 10)).foregroundStyle(Palette.muted).lineLimit(1)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }

    private var footer: String {
        let time = entry.updated.map { EntryBuilder.format($0, "HH:mm") } ?? "—"
        return "\(entry.groupName) · \(entry.offline ? "нет сети, копия" : "обновлено") \(time)"
    }
}

extension View {
    @ViewBuilder
    func widgetBackground<B: ShapeStyle>(_ style: B) -> some View {
        if #available(iOSApplicationExtension 17.0, *) {
            containerBackground(style, for: .widget)
        } else {
            padding().background(Rectangle().fill(style))
        }
    }
}

// MARK: - Виджет

struct ScheduleWidget: Widget {
    let kind = "ScheduleWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: Provider()) { entry in
            ScheduleWidgetView(entry: entry)
        }
        .configurationDisplayName("Расписание ОшТУ")
        .description("Пары на сегодня: группа, преподаватель или аудитория. Текущая пара подсвечена.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge, .accessoryRectangular, .accessoryInline])
    }
}

@main
struct ScheduleWidgetBundle: WidgetBundle {
    var body: some Widget {
        ScheduleWidget()
    }
}
