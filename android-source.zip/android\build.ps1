# Сборка APK без Gradle: aapt2 + javac + d8 + apksigner из Android SDK.
# Запуск:  powershell -ExecutionPolicy Bypass -File build.ps1 -VersionCode 2 -VersionName 1.1
param([int]$VersionCode = 1, [string]$VersionName = "1.0")
$ErrorActionPreference = "Stop"

$src = $PSScriptRoot
$sdk = "$env:LOCALAPPDATA\Android\Sdk"
$bt = Get-ChildItem "$sdk\build-tools" | Sort-Object Name -Descending | Select-Object -First 1 -ExpandProperty FullName
$jar = Get-ChildItem "$sdk\platforms" | Sort-Object Name -Descending | Select-Object -First 1 | ForEach-Object { "$($_.FullName)\android.jar" }
$env:JAVA_HOME = "C:\Program Files\Android\Android Studio\jbr"
$env:Path = "$env:JAVA_HOME\bin;$env:Path"

function Run($exe, [string[]]$a) {
  & $exe @a
  if ($LASTEXITCODE -ne 0) { throw "$exe failed ($LASTEXITCODE)" }
}

# сборка в папке с ASCII-путём (инструменты SDK не любят кириллицу)
$w = Join-Path ([IO.Path]::GetTempPath()) "oshtu-apk-build"
if (Test-Path $w) { Remove-Item -Recurse -Force $w }
New-Item -ItemType Directory $w | Out-Null
Copy-Item -Recurse "$src\res", "$src\src", "$src\AndroidManifest.xml" $w
Push-Location $w
try {
  Run "$bt\aapt2.exe" @("compile", "--dir", "res", "-o", "res.zip")
  Run "$bt\aapt2.exe" @("link", "-I", $jar, "--manifest", "AndroidManifest.xml", "-R", "res.zip", "--java", "gen",
    "-o", "base.apk", "--min-sdk-version", "24", "--target-sdk-version", "35",
    "--version-code", "$VersionCode", "--version-name", $VersionName, "--auto-add-overlay")

  $java = Get-ChildItem -Recurse -Filter *.java src, gen | ForEach-Object { $_.FullName }
  New-Item -ItemType Directory classes | Out-Null
  Run "javac" (@("-encoding", "UTF-8", "-source", "8", "-target", "8", "-nowarn", "-Xlint:-options",
    "-bootclasspath", $jar, "-d", "classes") + $java)

  $classes = Get-ChildItem -Recurse -Filter *.class classes | ForEach-Object { $_.FullName }
  Run "$bt\d8.bat" (@("--release", "--min-api", "24", "--lib", $jar, "--output", ".") + $classes)
  Run "$bt\aapt.exe" @("add", "base.apk", "classes.dex")
  Run "$bt\zipalign.exe" @("-f", "-p", "4", "base.apk", "aligned.apk")

  $ks = "$src\release.keystore"
  if (-not (Test-Path $ks)) {
    Run "keytool" @("-genkeypair", "-keystore", $ks, "-alias", "oshtu", "-keyalg", "RSA", "-keysize", "2048",
      "-validity", "10000", "-storepass", "oshtu-schedule", "-keypass", "oshtu-schedule",
      "-dname", "CN=Raspisanie OshTU, O=Student, C=KG")
  }
  Run "$bt\apksigner.bat" @("sign", "--ks", $ks, "--ks-key-alias", "oshtu", "--ks-pass", "pass:oshtu-schedule",
    "--key-pass", "pass:oshtu-schedule", "--out", "signed.apk", "aligned.apk")
  Run "$bt\apksigner.bat" @("verify", "signed.apk")

  Copy-Item signed.apk (Join-Path (Split-Path $src) "oshtu-schedule.apk") -Force
  Write-Host "OK -> oshtu-schedule.apk ($VersionName / $VersionCode)"
} finally {
  Pop-Location
}
