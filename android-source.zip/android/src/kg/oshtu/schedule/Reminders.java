package kg.oshtu.schedule;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.List;

/**
 * Напоминания перед парой со своей мелодией (res/raw/oshtu_chime.wav).
 * Всегда запланирован один будильник — на ближайшую пару; когда он срабатывает,
 * показываем уведомление и планируем следующий. Работает при закрытом приложении и после перезагрузки.
 */
public class Reminders extends BroadcastReceiver {
    static final String ACT_FIRE = "kg.oshtu.schedule.REMINDER";
    static final String CHANNEL = "lessons_chime_v1";
    private static final int REQ = 77;

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        final Context app = ctx.getApplicationContext();
        String a = intent.getAction();
        if (ACT_FIRE.equals(a)) {
            show(app, intent.getStringExtra("title"), intent.getStringExtra("body"), (int) (intent.getLongExtra("at", 0) / 60000));
        }
        // после срабатывания, перезагрузки, обновления приложения или смены времени — планируем следующее
        final PendingResult pending = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    long age = System.currentTimeMillis() - Schedule.prefs(app).getLong("cacheAt", 0);
                    if (age > 30 * 60 * 1000L) {
                        try { Schedule.fetch(app); } catch (Exception ignored) { }
                    }
                    schedule(app);
                    ScheduleWidget.renderAll(app);
                } finally {
                    pending.finish();
                }
            }
        }).start();
    }

    /** Запланировать ближайшее напоминание (или снять, если выключены). */
    static void schedule(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent cancel = pending(ctx, null, null, 0);
        am.cancel(cancel);

        int min = Schedule.notifyMin(ctx);
        if (min <= 0 || Schedule.groupId(ctx) <= 0 || !Schedule.hasCache(ctx)) return;

        long now = System.currentTimeMillis();
        Calendar day = Schedule.today();
        for (int i = 0; i < 9; i++) {
            List<Schedule.Pair> list = Schedule.lessonsOn(ctx, day);
            for (Schedule.Pair p : list) {
                if (p.start == null) continue;
                Calendar at = (Calendar) day.clone();
                int m = Schedule.minutes(p.start);
                at.set(Calendar.HOUR_OF_DAY, m / 60);
                at.set(Calendar.MINUTE, m % 60);
                long fire = at.getTimeInMillis() - min * 60000L;
                if (fire > now + 5000) {
                    String title = "Через " + min + " мин — " + p.n + "-я пара (" + p.start + ")";
                    String body = Schedule.detailLine(ctx, p.lessons.get(0));
                    setAlarm(ctx, am, fire, pending(ctx, title, body, at.getTimeInMillis()));
                    return;
                }
            }
            day = Schedule.addDays(day, 1);
        }
    }

    private static void setAlarm(Context ctx, AlarmManager am, long at, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                // без разрешения на точные будильники: окно ±1 минута
                am.setWindow(AlarmManager.RTC_WAKEUP, at - 30000, 60000, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private static PendingIntent pending(Context ctx, String title, String body, long at) {
        Intent i = new Intent(ctx, Reminders.class).setAction(ACT_FIRE);
        if (title != null) i.putExtra("title", title).putExtra("body", body).putExtra("at", at);
        return PendingIntent.getBroadcast(ctx, REQ, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || nm.getNotificationChannel(CHANNEL) != null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Напоминания о парах", NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Мелодия за несколько минут до начала пары");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 150, 80, 150});
        ch.setSound(soundUri(ctx), new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build());
        nm.createNotificationChannel(ch);
    }

    static Uri soundUri(Context ctx) {
        return Uri.parse("android.resource://" + ctx.getPackageName() + "/" + R.raw.oshtu_chime);
    }

    @SuppressWarnings("deprecation")
    static void show(Context ctx, String title, String body, int id) {
        if (title == null) return;
        ensureChannel(ctx);
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        Intent open = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 20, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CHANNEL) : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setColor(0xFF5B5BF6)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(soundUri(ctx)).setPriority(Notification.PRIORITY_HIGH).setVibrate(new long[]{0, 150, 80, 150});
        }
        try {
            nm.notify(1000 + Math.abs(id % 100000), b.build());
        } catch (SecurityException ignored) {
            // нет разрешения на уведомления
        }
    }
}
