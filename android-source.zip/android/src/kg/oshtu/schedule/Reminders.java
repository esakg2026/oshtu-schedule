package kg.oshtu.schedule;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

import java.util.Calendar;
import java.util.List;

/**
 * Напоминания перед парой. Три стиля (настройка notifyStyle):
 *  simple — стандартный звук уведомления телефона;
 *  melody — своя мелодия res/raw/oshtu_chime.wav;
 *  voice  — мелодия, затем голос (TextToSpeech) рассказывает о занятии (SpeakService).
 * Всегда запланирован один будильник — на ближайшую пару; при срабатывании планируется следующий.
 */
public class Reminders extends BroadcastReceiver {
    static final String ACT_FIRE = "kg.oshtu.schedule.REMINDER";
    static final String CH_SIMPLE = "lessons_simple_v1";
    static final String CH_MELODY = "lessons_chime_v1";
    static final String CH_VOICE = "lessons_voice_v1";
    private static final int REQ = 77;

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        final Context app = ctx.getApplicationContext();
        if (ACT_FIRE.equals(intent.getAction())) {
            fire(app, intent.getStringExtra("title"), intent.getStringExtra("body"), intent.getStringExtra("speech"),
                    (int) (intent.getLongExtra("at", 0) / 60000));
        }
        // после срабатывания, перезагрузки, обновления приложения или смены времени — планируем следующее
        final PendingResult pending = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    long age = System.currentTimeMillis() - Schedule.prefs(app).getLong("cacheAt", 0);
                    if (age > 30 * 60 * 1000L) {
                        try { Schedule.fetch(app); } catch (Exception ignored) { }
                    }
                    schedule(app);
                    ScheduleWidget.renderAll(app);
                } finally {
                    pending.finish();
                }
            }
        }).start();
    }

    /** Показать напоминание в выбранном стиле. */
    static void fire(Context ctx, String title, String body, String speech, int id) {
        if (title == null) return;
        String style = Schedule.notifyStyle(ctx);
        if ("voice".equals(style)) {
            Intent s = new Intent(ctx, SpeakService.class)
                    .putExtra("title", title).putExtra("body", body)
                    .putExtra("speech", speech == null ? title + ". " + body : speech)
                    .putExtra("id", id);
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(s);
                else ctx.startService(s);
                return;
            } catch (Exception e) {
                // система не дала запустить озвучку (например, неточный будильник) — хотя бы с мелодией
                show(ctx, title, body, id, CH_MELODY);
                return;
            }
        }
        show(ctx, title, body, id, "simple".equals(style) ? CH_SIMPLE : CH_MELODY);
    }

    /** Запланировать ближайшее напоминание (или снять, если выключены). */
    static void schedule(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        am.cancel(pending(ctx, null, null, null, 0));

        int min = Schedule.notifyMin(ctx);
        if (min <= 0 || Schedule.groupId(ctx) <= 0 || !Schedule.hasCache(ctx)) return;

        long now = System.currentTimeMillis();
        Calendar day = Schedule.today();
        for (int i = 0; i < 9; i++) {
            List<Schedule.Pair> list = Schedule.lessonsOn(ctx, day);
            for (Schedule.Pair p : list) {
                if (p.start == null) continue;
                Calendar at = (Calendar) day.clone();
                int m = Schedule.minutes(p.start);
                at.set(Calendar.HOUR_OF_DAY, m / 60);
                at.set(Calendar.MINUTE, m % 60);
                long fire = at.getTimeInMillis() - min * 60000L;
                if (fire > now + 5000) {
                    String title = "Через " + min + " мин — " + p.n + "-я пара (" + p.start + ")";
                    String body = Schedule.detailLine(ctx, p.lessons.get(0));
                    String speech = Schedule.speechText(ctx, p, min);
                    setAlarm(am, fire, pending(ctx, title, body, speech, at.getTimeInMillis()));
                    return;
                }
            }
            day = Schedule.addDays(day, 1);
        }
    }

    private static void setAlarm(AlarmManager am, long at, PendingIntent pi) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setWindow(AlarmManager.RTC_WAKEUP, at - 30000, 60000, pi);
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, at, pi);
        }
    }

    private static PendingIntent pending(Context ctx, String title, String body, String speech, long at) {
        Intent i = new Intent(ctx, Reminders.class).setAction(ACT_FIRE);
        if (title != null) i.putExtra("title", title).putExtra("body", body).putExtra("speech", speech).putExtra("at", at);
        return PendingIntent.getBroadcast(ctx, REQ, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    static void ensureChannels(Context ctx) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        long[] vib = {0, 150, 80, 150};
        if (nm.getNotificationChannel(CH_MELODY) == null) {
            NotificationChannel ch = new NotificationChannel(CH_MELODY, "Напоминания: мелодия", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Своя мелодия «Расписания ОшТУ» перед парой");
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            ch.setSound(soundUri(ctx), aa);
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_SIMPLE) == null) {
            NotificationChannel ch = new NotificationChannel(CH_SIMPLE, "Напоминания: простой звук", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Стандартный звук уведомления телефона");
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            ch.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION), aa);
            nm.createNotificationChannel(ch);
        }
        if (nm.getNotificationChannel(CH_VOICE) == null) {
            // звук и голос воспроизводит SpeakService, сам канал беззвучный
            NotificationChannel ch = new NotificationChannel(CH_VOICE, "Напоминания: голос", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Голос рассказывает о ближайшем занятии");
            ch.enableVibration(true);
            ch.setVibrationPattern(vib);
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
        }
    }

    /** Совместимость со старым вызовом. */
    static void ensureChannel(Context ctx) { ensureChannels(ctx); }

    static Uri soundUri(Context ctx) {
        return Uri.parse("android.resource://" + ctx.getPackageName() + "/" + R.raw.oshtu_chime);
    }

    @SuppressWarnings("deprecation")
    static Notification build(Context ctx, String title, String body, String channel) {
        ensureChannels(ctx);
        Intent open = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 20, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, channel) : new Notification.Builder(ctx);
        b.setSmallIcon(R.drawable.ic_notify)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setColor(0xFF5B5BF6)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true);
        if (Build.VERSION.SDK_INT < 26) {
            b.setPriority(Notification.PRIORITY_HIGH).setVibrate(new long[]{0, 150, 80, 150});
            if (CH_MELODY.equals(channel)) b.setSound(soundUri(ctx));
            else if (CH_SIMPLE.equals(channel)) b.setDefaults(Notification.DEFAULT_SOUND);
        }
        return b.build();
    }

    static void show(Context ctx, String title, String body, int id, String channel) {
        if (title == null) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        try {
            nm.notify(notifId(id), build(ctx, title, body, channel));
        } catch (SecurityException ignored) {
            // нет разрешения на уведомления
        }
    }

    /** Старый вызов: показать с мелодией. */
    static void show(Context ctx, String title, String body, int id) { show(ctx, title, body, id, CH_MELODY); }

    static int notifId(int id) { return 1000 + Math.abs(id % 100000); }
}
