package kg.oshtu.schedule;

import android.content.Context;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/** Тексты виджета, уведомлений и голоса на трёх языках: ru, ky, en (выбирается в приложении). */
final class Lang {
    private Lang() {}

    private static final Map<String, String[]> T = new HashMap<>();

    /** ключ → {ru, ky, en} */
    private static void put(String k, String ru, String ky, String en) { T.put(k, new String[]{ru, ky, en}); }

    static {
        put("app", "Расписание ОшТУ", "ОшТУ жадыбалы", "OshTU Schedule");
        put("open", "Открой приложение и выбери группу, преподавателя или аудиторию",
                "Тиркемени ачып, топту, окутуучуну же аудиторияны тандаңыз",
                "Open the app and choose a group, teacher or room");
        put("today", "Сегодня", "Бүгүн", "Today");
        put("tomorrow", "Завтра", "Эртең", "Tomorrow");
        put("yesterday", "Вчера", "Кечээ", "Yesterday");
        put("top", "верхняя", "үстүңкү", "top");
        put("bottom", "нижняя", "астыңкы", "bottom");
        put("loading", "Загрузка…", "Жүктөлүүдө…", "Loading…");
        put("sunday", "Воскресенье — выходной", "Жекшемби — дем алыш", "Sunday — day off");
        put("none", "Пар нет 🎉", "Сабак жок 🎉", "No classes 🎉");
        put("now", "Сейчас %d-я пара · ещё %s", "Азыр %d-пара · дагы %s", "Period %d now · %s left");
        put("first", "Первая пара через %s", "Биринчи пара %s кийин", "First class in %s");
        put("next", "Дальше %d-я пара через %s", "%d-пара %s кийин", "Period %d in %s");
        put("over", "Пары на сегодня закончились", "Бүгүнкү сабактар бүттү", "Classes are over for today");
        put("overFirst", "Сегодня пары закончились · первая в %s", "Бүгүнкү сабактар бүттү · биринчиси %s", "Done for today · first class at %s");
        put("offline", "нет сети, копия от ", "тармак жок, көчүрмө ", "offline, copy from ");
        put("updated", "обновлено ", "жаңыланды ", "updated ");
        put("room", "ауд. ", "ауд. ", "room ");
        put("sub", "%s подгр.", "%s-топчо", "subgr. %s");
        put("h", "ч", "саат", "h");
        put("min", "мин", "мүн", "min");
        put("remTitle", "Через %d мин — %d-я пара (%s)", "%d мүнөттөн кийин — %d-пара (%s)", "In %d min — period %d (%s)");
        put("remDefault", "Напоминание о паре", "Сабак тууралуу эскертүү", "Class reminder");
        put("lesson", "Занятие", "Сабак", "Class");
        put("chMelody", "Напоминания: мелодия", "Эскертүүлөр: обон", "Reminders: melody");
        put("chMelodyD", "Своя мелодия «Расписания ОшТУ» перед парой", "Пара алдында «ОшТУ жадыбалынын» өз обону", "The app's own melody before class");
        put("chSimple", "Напоминания: простой звук", "Эскертүүлөр: жөнөкөй үн", "Reminders: simple sound");
        put("chSimpleD", "Стандартный звук уведомления телефона", "Телефондун кадимки билдирме үнү", "The phone's standard notification sound");
        put("chVoice", "Напоминания: голос", "Эскертүүлөр: үн менен", "Reminders: voice");
        put("chVoiceD", "Голос рассказывает о ближайшем занятии", "Үн жакынкы сабак тууралуу айтып берет", "A voice tells you about the next class");
        put("lec", "лк.", "лк.", "lec.");
        put("prac", "пр.", "пр.", "pr.");
        put("lab", "лаб.", "лаб.", "lab");
        put("sem", "сем.", "сем.", "sem.");
    }

    private static final String[][] WD = {
            {"", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"},
            {"", "дүйшөмбү", "шейшемби", "шаршемби", "бейшемби", "жума", "ишемби", "жекшемби"},
            {"", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"},
    };
    private static final String[][] WDS = {
            {"", "пн", "вт", "ср", "чт", "пт", "сб", "вс"},
            {"", "дш", "шш", "шр", "бш", "жм", "иш", "жк"},
            {"", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"},
    };
    private static final String[][] MON = {
            {"янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"},
            {"янв", "фев", "мар", "апр", "май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"},
            {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"},
    };

    /** "ru", "ky" или "en" */
    static String code(Context c) {
        String l = Schedule.prefs(c).getString("lang", "ru");
        return "ky".equals(l) || "en".equals(l) ? l : "ru";
    }

    static int idx(Context c) {
        String l = code(c);
        return "ky".equals(l) ? 1 : "en".equals(l) ? 2 : 0;
    }

    static String t(Context c, String key) {
        String[] v = T.get(key);
        return v == null ? key : v[idx(c)];
    }

    static String f(Context c, String key, Object... args) {
        return String.format(java.util.Locale.ROOT, t(c, key), args);
    }

    private static String cap(String s) { return s.isEmpty() ? s : s.substring(0, 1).toUpperCase() + s.substring(1); }

    static String weekday(Context c, Calendar d) { return cap(WD[idx(c)][Schedule.isoDow(d)]); }

    /** «пн, 16 ноя» / «дш, 16-ноя» / «Mon, 16 Nov» */
    static String shortDate(Context c, Calendar d) {
        int i = idx(c);
        String day = String.valueOf(d.get(Calendar.DAY_OF_MONTH));
        return WDS[i][Schedule.isoDow(d)] + ", " + day + (i == 1 ? "-" : " ") + MON[i][d.get(Calendar.MONTH)];
    }
}
