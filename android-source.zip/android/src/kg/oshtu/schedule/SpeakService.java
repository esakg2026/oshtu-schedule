package kg.oshtu.schedule;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Голосовое напоминание: показывает уведомление, играет мелодию, затем голосом (русский TTS)
 * рассказывает о занятии. Короткий foreground-сервис, чтобы речь не оборвалась.
 */
public class SpeakService extends Service implements TextToSpeech.OnInitListener {
    private TextToSpeech tts;
    private MediaPlayer player;
    private String speech;
    private boolean finished;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final AudioAttributes ATTRS = new AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = intent.getStringExtra("title");
        String body = intent.getStringExtra("body");
        speech = intent.getStringExtra("speech");
        int id = Reminders.notifId(intent.getIntExtra("id", 0));
        Notification n = Reminders.build(this, title == null ? Lang.t(this, "remDefault") : title, body == null ? "" : body, Reminders.CH_VOICE);
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(id, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            else startForeground(id, n);
        } catch (Exception e) {
            Reminders.show(this, title, body, id, Reminders.CH_MELODY);
            stopSelf();
            return START_NOT_STICKY;
        }
        handler.postDelayed(new Runnable() {
            @Override public void run() { finish(); }
        }, 40000); // страховка
        playChimeThenSpeak();
        return START_NOT_STICKY;
    }

    private void playChimeThenSpeak() {
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(ATTRS);
            player.setDataSource(this, Reminders.soundUri(this));
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer mp) { startSpeech(); }
            });
            player.prepare();
            player.start();
        } catch (Exception e) {
            startSpeech();
        }
    }

    private void startSpeech() {
        if (tts == null && !finished) tts = new TextToSpeech(getApplicationContext(), this);
    }

    @Override
    public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS || tts == null || speech == null) {
            finish();
            return;
        }
        String lang = Lang.code(this);
        final Locale ru = new Locale("ru", "RU");
        Locale main = ru;
        if ("ky".equals(lang) && available(new Locale("ky", "KG"))) main = new Locale("ky", "KG"); // нет кыргызского — читает русский голос
        if ("en".equals(lang) && available(Locale.US)) main = Locale.US;
        if (!available(main)) {
            finish(); // нет нужного голоса — остаётся уведомление и мелодия
            return;
        }
        tts.setSpeechRate(0.95f);
        tts.setAudioAttributes(ATTRS);
        // в английском тексте русские названия предметов и ФИО читает русский голос
        final List<String[]> parts = Locale.US.equals(main) && available(ru) ? segments(speech) : null;
        final int total = parts == null ? 1 : parts.size();
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) {
                if (id.equals("oshtu-" + (total - 1))) handler.post(new Runnable() { @Override public void run() { finish(); } });
            }
            @Override public void onError(String id) { handler.post(new Runnable() { @Override public void run() { finish(); } }); }
        });
        if (parts == null) {
            tts.setLanguage(main);
            tts.speak(speech, TextToSpeech.QUEUE_FLUSH, new Bundle(), "oshtu-0");
            return;
        }
        for (int i = 0; i < parts.size(); i++) {
            tts.setLanguage("ru".equals(parts.get(i)[0]) ? ru : Locale.US); // язык фиксируется в момент вызова speak()
            tts.speak(parts.get(i)[1], i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, new Bundle(), "oshtu-" + i);
        }
    }

    private boolean available(Locale l) {
        try {
            return tts.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE;
        } catch (Exception e) {
            return false;
        }
    }

    /** Разбить текст на куски «ru»/«en» по алфавиту слов. */
    static List<String[]> segments(String text) {
        List<String[]> out = new ArrayList<>();
        String[] words = text.split("(?<=\\s)");
        for (String w : words) {
            String k = w.matches("(?s).*[А-Яа-яЁёӨөҮүҢң].*") ? "ru" : w.matches("(?s).*[A-Za-z].*") ? "en" : null;
            if (out.isEmpty()) out.add(new String[]{k == null ? "en" : k, w});
            else {
                String[] last = out.get(out.size() - 1);
                if (k != null && !k.equals(last[0])) out.add(new String[]{k, w});
                else last[1] += w;
            }
        }
        List<String[]> clean = new ArrayList<>();
        for (String[] s : out) if (!s[1].trim().isEmpty()) clean.add(s);
        return clean;
    }

    @SuppressWarnings("deprecation")
    private void finish() {
        if (finished) return;
        finished = true;
        handler.removeCallbacksAndMessages(null);
        try { if (player != null) player.release(); } catch (Exception ignored) { }
        try { if (tts != null) { tts.stop(); tts.shutdown(); } } catch (Exception ignored) { }
        // уведомление остаётся в шторке
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_DETACH);
        else stopForeground(false);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        finish();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
