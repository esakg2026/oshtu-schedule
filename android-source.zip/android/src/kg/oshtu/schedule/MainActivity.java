package kg.oshtu.schedule;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/** Приложение = веб-версия расписания в WebView + мост, передающий выбранную группу виджету. */
public class MainActivity extends Activity {
    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        applyBars();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " OshtuAndroid/1.0");
        web.setBackgroundColor(isNight() ? Color.parseColor("#0D0F17") : Color.parseColor("#F4F5FB"));
        web.addJavascriptInterface(new Bridge(), "OshtuAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (Uri.parse(Schedule.SITE).getHost().equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
        });
        // Android 15+ рисует приложение под системными панелями — отодвигаем контент сами
        web.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                if (Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets i = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                    v.setPadding(i.left, i.top, i.right, i.bottom);
                } else {
                    v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                            insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
                }
                return insets;
            }
        });
        setContentView(web);
        if (state != null) web.restoreState(state);
        else web.loadUrl(Schedule.SITE + "/?source=android");
    }

    private boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    private void applyBars() {
        Window w = getWindow();
        boolean night = isNight();
        int bg = night ? Color.parseColor("#0D0F17") : Color.parseColor("#F4F5FB");
        w.setStatusBarColor(bg);
        w.setNavigationBarColor(bg);
        if (!night && Build.VERSION.SDK_INT >= 23) {
            int flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(flags);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        ScheduleWidget.requestRefresh(this);
        Reminders.schedule(getApplicationContext());
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == 5) askExactAlarms();
    }

    /** Точное время напоминаний: на Android 12+ просим разрешение один раз. */
    private void askExactAlarms() {
        if (Build.VERSION.SDK_INT < 31) return;
        android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(ALARM_SERVICE);
        if (am == null || am.canScheduleExactAlarms()) return;
        if (Schedule.prefs(this).getBoolean("askedExact", false)) return;
        Schedule.prefs(this).edit().putBoolean("askedExact", true).apply();
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) {
        }
    }

    final class Bridge {
        @JavascriptInterface
        public void saveSettings(String json) {
            try {
                Schedule.saveSettings(getApplicationContext(), json);
                ScheduleWidget.requestRefresh(getApplicationContext());
                Reminders.schedule(getApplicationContext());
            } catch (Exception ignored) {
            }
        }

        /** Разрешения: уведомления (Android 13+) и точные будильники (Android 12+). */
        @JavascriptInterface
        public void requestNotifications() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Reminders.ensureChannel(MainActivity.this);
                    if (Build.VERSION.SDK_INT >= 33
                            && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 5);
                        return;
                    }
                    askExactAlarms();
                }
            });
        }

        /** Пробное напоминание в выбранном стиле (простой / мелодия / голос). */
        @JavascriptInterface
        public void testReminder(String title, String body, String speech) {
            Reminders.fire(getApplicationContext(), title, body, speech, (int) (System.currentTimeMillis() / 1000));
        }

        @JavascriptInterface
        public void testReminder() {
            testReminder("Через 5 мин — 4-я пара (12:50)", "Так будет звучать напоминание о паре",
                    "До занятия осталось 5 минут. Так будет звучать голосовое напоминание.");
        }

        @JavascriptInterface
        public boolean isApp() {
            return true;
        }
    }
}
