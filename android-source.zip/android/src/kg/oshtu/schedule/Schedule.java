package kg.oshtu.schedule;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Загрузка, кэш и разбор расписания (та же логика, что в core.js веб-версии). */
final class Schedule {
    static final String SITE = "https://oshtu-schedule.onrender.com";
    // сначала через прокси на своём домене (работает, если провайдер блокирует supabase.co), потом напрямую
    static final String[] API = {SITE + "/sb", "https://pzdraaxgzphxennadrlu.supabase.co"};
    static final String KEY = "sb_publishable_DjYWqTHsA02JavCvE3y5Eg_xVNezrf1";

    static final String[][] TIMES = {
            null,
            {"08:00", "09:20"}, {"09:30", "10:50"}, {"11:20", "12:40"},
            {"12:50", "14:10"}, {"14:20", "15:40"}, {"15:50", "17:10"},
    };

    static final class Lesson {
        String subject = "", type = "", teacher = "", room = "", group = "", sub = "";
    }

    static final class Pair {
        int n;
        String start, end;
        List<Lesson> lessons;
    }

    private Schedule() {}

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("oshtu", Context.MODE_PRIVATE);
    }

    // ---------- настройки (приходят из веб-приложения через мост) ----------
    /** "group", "teacher" или "room" */
    static String kind(Context c) { return prefs(c).getString("mode", "group"); }
    /** ID группы, преподавателя или аудитории */
    static int groupId(Context c) { return prefs(c).getInt("targetId", prefs(c).getInt("groupId", 0)); }
    static String groupName(Context c) { return prefs(c).getString("targetName", prefs(c).getString("groupName", "")); }
    static boolean flip(Context c) { return prefs(c).getBoolean("weekFlip", false); }
    /** за сколько минут напоминать (0 — выключено) */
    static int notifyMin(Context c) { return prefs(c).getInt("notify", 5); }
    /** "simple" — стандартный звук, "melody" — своя мелодия, "voice" — мелодия + голос */
    static String notifyStyle(Context c) { return prefs(c).getString("notifyStyle", "melody"); }

    static int semester(Context c) {
        String s = prefs(c).getString("semester", "auto");
        if ("1".equals(s)) return 1;
        if ("2".equals(s)) return 2;
        int m = Calendar.getInstance().get(Calendar.MONTH); // 0..11
        return (m >= 1 && m <= 6) ? 1 : 2;
    }

    static void saveSettings(Context c, String json) throws Exception {
        JSONObject o = new JSONObject(json);
        String mode = o.optString("mode", "group");
        if (!"teacher".equals(mode) && !"room".equals(mode)) mode = "group";
        int target = o.optInt("targetId", o.optInt("groupId", 0));
        String name = o.optString("targetName", o.optString("groupName", ""));
        String newSem = String.valueOf(o.opt("semester") == null ? "auto" : o.opt("semester"));
        SharedPreferences p = prefs(c);
        SharedPreferences.Editor e = p.edit();
        if (target != groupId(c) || !mode.equals(kind(c)) || !newSem.equals(p.getString("semester", "auto"))) {
            e.remove("cache").remove("cacheAt");
        }
        e.putString("mode", mode)
                .putInt("targetId", target)
                .putString("targetName", name)
                .putString("semester", newSem)
                .putBoolean("weekFlip", o.optBoolean("weekFlip", false))
                .putInt("notify", o.optInt("notify", 5))
                .putString("notifyStyle", o.optString("notifyStyle", "melody"))
                .apply();
    }

    // ---------- сеть ----------
    static String fetch(Context c) throws Exception {
        int group = groupId(c);
        if (group <= 0) throw new IOException("no group");
        JSONObject body = new JSONObject();
        body.put("p_kind", kind(c));
        body.put("p_id", group);
        body.put("p_semester", semester(c));
        String name = groupName(c);
        body.put("p_name", name.isEmpty() ? JSONObject.NULL : name);
        body.put("p_max_age_sec", 300);

        Exception last = null;
        for (String base : API) {
            HttpURLConnection con = null;
            try {
                con = (HttpURLConnection) new URL(base + "/rest/v1/rpc/oshtu_timetable").openConnection();
                con.setConnectTimeout(8000);
                con.setReadTimeout(15000);
                con.setRequestMethod("POST");
                con.setDoOutput(true);
                con.setRequestProperty("apikey", KEY);
                con.setRequestProperty("Content-Type", "application/json");
                OutputStream os = con.getOutputStream();
                os.write(body.toString().getBytes("UTF-8"));
                os.close();
                int code = con.getResponseCode();
                if (code >= 200 && code < 300) {
                    String s = read(con.getInputStream());
                    new JSONObject(s); // проверка
                    prefs(c).edit().putString("cache", s)
                            .putLong("cacheAt", System.currentTimeMillis())
                            .putBoolean("lastFailed", false).apply();
                    return s;
                }
                last = new IOException("HTTP " + code);
            } catch (Exception ex) {
                last = ex;
            } finally {
                if (con != null) con.disconnect();
            }
        }
        prefs(c).edit().putBoolean("lastFailed", true).apply();
        throw last;
    }

    private static String read(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int r;
        while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
        in.close();
        return bo.toString("UTF-8");
    }

    // ---------- даты и недели ----------
    static Calendar today() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c;
    }

    static Calendar addDays(Calendar d, int n) {
        Calendar c = (Calendar) d.clone();
        c.add(Calendar.DAY_OF_MONTH, n);
        return c;
    }

    /** Пн=1 … Вс=7 */
    static int isoDow(Calendar d) {
        int w = d.get(Calendar.DAY_OF_WEEK); // Вс=1
        return w == Calendar.SUNDAY ? 7 : w - 1;
    }

    static Calendar monday(Calendar d) { return addDays(d, -(isoDow(d) - 1)); }

    private static long epochDay(Calendar d) {
        GregorianCalendar u = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
        u.clear();
        u.set(d.get(Calendar.YEAR), d.get(Calendar.MONTH), d.get(Calendar.DAY_OF_MONTH));
        return u.getTimeInMillis() / 86400000L;
    }

    static String weekKey(Calendar d) {
        Calendar m = monday(d);
        return String.format(Locale.US, "%04d-%02d-%02d",
                m.get(Calendar.YEAR), m.get(Calendar.MONTH) + 1, m.get(Calendar.DAY_OF_MONTH));
    }

    /** Неделя 9–14 ноября 2026 на сайте ОшТУ — «верхняя». */
    static boolean isTopWeek(Calendar d, boolean flip) {
        Calendar anchor = new GregorianCalendar(2026, Calendar.NOVEMBER, 9);
        long weeks = Math.round((epochDay(monday(d)) - epochDay(anchor)) / 7.0);
        boolean top = ((weeks % 2) + 2) % 2 == 0;
        return flip != top;
    }

    static boolean sameDay(Calendar a, Calendar b) { return epochDay(a) == epochDay(b); }

    static int minutes(String hhmm) {
        String[] p = hhmm.split(":");
        return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
    }

    static int nowMinutes() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE);
    }

    // ---------- разбор HTML ячейки ----------
    private static final int RX = Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
    private static final Pattern TYPE_LINE = Pattern.compile("^(.*?)\\s*\\((лк|пр|лб|лаб|сем)[^)]*\\)\\s*(?:\\[([^\\]]+)\\])?\\s*$", RX);
    private static final Pattern SUB = Pattern.compile("^\\((\\d+)\\)\\s*(.*)$");
    private static final Pattern GROUP_TEACHER = Pattern.compile("^(\\S*\\d\\S*)\\s+(.+)$");
    private static final Pattern TYPE_ANY = Pattern.compile("\\((лк|пр|лб|лаб|сем)[^)]*\\)", RX);
    private static final Pattern ROOM = Pattern.compile("^(.*?)\\s*\\[([^\\]]+)\\]\\s*$");

    private static String decode(String s) {
        return s.replace("&nbsp;", " ").replace("&quot;", "\"").replace("&#39;", "'")
                .replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&");
    }

    /**
     * Формат ячейки зависит от режима:
     * group:   «(1) Предмет (лк.)» / «Преподаватель [корпус/ауд]»
     * teacher: «(1) ПИ-1-24 (лк.)  [3/303]» / «Предмет»
     * room:    «(1) Предмет (лк.)» / «ПИ-1-24 Преподаватель»
     */
    static List<Lesson> parseBlock(String html, String kind) {
        List<String> lines = new ArrayList<>();
        for (String part : html.split("(?i)<br\\s*/?>")) {
            String t = decode(part.replaceAll("<[^>]+>", "")).replaceAll("\\s+", " ").trim();
            if (!t.isEmpty()) lines.add(t);
        }
        List<Lesson> out = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i);
            Matcher m = TYPE_LINE.matcher(line);
            if (m.matches()) {
                Lesson l = new Lesson();
                String head = m.group(1).trim();
                Matcher sm = SUB.matcher(head);
                if (sm.matches()) {
                    l.sub = sm.group(1);
                    head = sm.group(2).trim();
                }
                l.type = m.group(2).toLowerCase(Locale.ROOT).substring(0, 2);
                if (m.group(3) != null) l.room = m.group(3).trim();
                String next = (i + 1 < lines.size() && !TYPE_ANY.matcher(lines.get(i + 1)).find()) ? lines.get(i + 1) : null;
                if ("teacher".equals(kind)) {
                    l.group = head;
                    if (next != null) { l.subject = next; i++; }
                } else if ("room".equals(kind)) {
                    l.subject = head;
                    if (next != null) {
                        Matcher g = GROUP_TEACHER.matcher(next);
                        if (g.matches()) { l.group = g.group(1); l.teacher = g.group(2); } else l.teacher = next;
                        i++;
                    }
                } else {
                    l.subject = head;
                    if (next != null) {
                        Matcher r = ROOM.matcher(next);
                        if (r.matches()) {
                            l.teacher = r.group(1).trim();
                            l.room = r.group(2).trim();
                        } else l.teacher = next;
                        i++;
                    }
                }
                if (l.subject.isEmpty()) l.subject = l.group.isEmpty() ? "Занятие" : l.group;
                out.add(l);
            } else {
                Matcher r = ROOM.matcher(line);
                Lesson last = out.isEmpty() ? null : out.get(out.size() - 1);
                if (r.matches() && last != null && last.teacher.isEmpty()) {
                    last.teacher = r.group(1).trim();
                    last.room = r.group(2).trim();
                } else {
                    Lesson l = new Lesson();
                    l.subject = line;
                    out.add(l);
                }
            }
        }
        return out;
    }

    /** [верхняя, нижняя] или null, если пусто */
    @SuppressWarnings("unchecked")
    static List<Lesson>[] parseCell(String html, String kind) {
        if (html == null || html.replaceAll("<[^>]+>|\\s|&nbsp;", "").isEmpty()) return null;
        String[] parts = html.split("(?i)<hr[^>]*>", -1);
        if (parts.length == 1) {
            List<Lesson> l = parseBlock(parts[0], kind);
            return l.isEmpty() ? null : new List[]{l, l};
        }
        StringBuilder rest = new StringBuilder();
        for (int i = 1; i < parts.length; i++) rest.append(parts[i]);
        List<Lesson> top = parseBlock(parts[0], kind);
        List<Lesson> bottom = parseBlock(rest.toString(), kind);
        return (top.isEmpty() && bottom.isEmpty()) ? null : new List[]{top, bottom};
    }

    // ---------- выбор версии недели ----------
    private static JSONArray pickRaw(JSONObject data, String key) {
        JSONArray weeks = data.optJSONArray("weeks");
        if (weeks != null && weeks.length() > 0) {
            JSONObject exact = null, before = null, earliest = null;
            for (int i = 0; i < weeks.length(); i++) {
                JSONObject w = weeks.optJSONObject(i);
                if (w == null) continue;
                String ws = w.optString("week_start");
                if (ws.equals(key)) exact = w;
                if (ws.compareTo(key) < 0 && (before == null || ws.compareTo(before.optString("week_start")) > 0)) before = w;
                if (earliest == null || ws.compareTo(earliest.optString("week_start")) < 0) earliest = w;
            }
            JSONObject pick = exact != null ? exact : before != null ? before : earliest;
            if (pick != null && pick.optJSONArray("raw") != null) return pick.optJSONArray("raw");
        }
        JSONArray raw = data.optJSONArray("raw");
        return raw != null ? raw : new JSONArray();
    }

    static boolean hasCache(Context c) { return prefs(c).getString("cache", null) != null; }

    /** Пары дня или пустой список. */
    static List<Pair> lessonsOn(Context c, Calendar day) {
        List<Pair> out = new ArrayList<>();
        String cache = prefs(c).getString("cache", null);
        int wd = isoDow(day);
        if (cache == null || wd > 6) return out;
        try {
            JSONArray raw = pickRaw(new JSONObject(cache), weekKey(day));
            boolean top = isTopWeek(day, flip(c));
            String kind = kind(c);
            for (int i = 0; i < raw.length(); i++) {
                JSONObject row = raw.optJSONObject(i);
                if (row == null) continue;
                List<Lesson>[] cell = parseCell(row.optString("WeekDay" + wd, ""), kind);
                if (cell == null) continue;
                List<Lesson> l = top ? cell[0] : cell[1];
                if (l.isEmpty()) continue;
                Pair p = new Pair();
                p.n = row.optInt("PairNumber");
                if (p.n >= 1 && p.n < TIMES.length) {
                    p.start = TIMES[p.n][0];
                    p.end = TIMES[p.n][1];
                }
                p.lessons = l;
                out.add(p);
            }
        } catch (Exception ignored) {
        }
        Collections.sort(out, new Comparator<Pair>() {
            @Override public int compare(Pair a, Pair b) { return a.n - b.n; }
        });
        return out;
    }

    static int lastEnd(List<Pair> list) {
        int e = -1;
        for (Pair p : list) if (p.end != null) e = Math.max(e, minutes(p.end));
        return e;
    }

    /** День по умолчанию: сегодня; после окончания пар и в воскресенье — следующий учебный день. */
    static Calendar baseDay(Context c) {
        Calendar d = today();
        if (isoDow(d) == 7) return addDays(d, 1);
        List<Pair> list = lessonsOn(c, d);
        int now = nowMinutes();
        int end = lastEnd(list);
        boolean over = (!list.isEmpty() && end > 0 && now >= end)
                || (list.isEmpty() && hasCache(c) && now >= 17 * 60);
        if (over) {
            d = addDays(d, 1);
            if (isoDow(d) == 7) d = addDays(d, 1);
        }
        return d;
    }

    /** Показанный в виджете день с учётом кнопок ‹ › (сдвиг сбрасывается на следующий день). */
    static Calendar shownDay(Context c) {
        SharedPreferences p = prefs(c);
        Calendar d = baseDay(c);
        String todayKey = String.valueOf(epochDay(today()));
        int offset = todayKey.equals(p.getString("offsetDay", "")) ? p.getInt("offset", 0) : 0;
        int step = offset > 0 ? 1 : -1;
        for (int i = 0; i < Math.abs(offset); i++) {
            d = addDays(d, step);
            if (isoDow(d) == 7) d = addDays(d, step);
        }
        return d;
    }

    static void shiftOffset(Context c, int delta) {
        SharedPreferences p = prefs(c);
        String todayKey = String.valueOf(epochDay(today()));
        int offset = todayKey.equals(p.getString("offsetDay", "")) ? p.getInt("offset", 0) : 0;
        p.edit().putInt("offset", delta == 0 ? 0 : offset + delta).putString("offsetDay", todayKey).apply();
    }

    /** Короткая правая колонка виджета: аудитория для группы, группа для преподавателя и аудитории. */
    static String rightInfo(Context c, Lesson l) {
        return "group".equals(kind(c)) ? l.room : l.group;
    }

    /** Подробная строка для уведомления. */
    static String detailLine(Context c, Lesson l) {
        List<String> parts = new ArrayList<>();
        parts.add(l.subject + (typeShort(l.type).isEmpty() ? "" : " (" + typeShort(l.type) + ")"));
        String k = kind(c);
        if (!"group".equals(k) && !l.group.isEmpty()) parts.add(l.group);
        if (!"teacher".equals(k) && !l.teacher.isEmpty()) parts.add(l.teacher);
        if (!"room".equals(k) && !l.room.isEmpty()) parts.add("ауд. " + l.room);
        if (!l.sub.isEmpty()) parts.add(l.sub + " подгр.");
        return join(parts, " · ");
    }

    private static final String[] ORD = {"", "первая", "вторая", "третья", "четвёртая", "пятая", "шестая", "седьмая"};

    private static String typeWord(String t) {
        if ("лк".equals(t)) return "лекция";
        if ("пр".equals(t)) return "практика";
        if ("лб".equals(t) || "ла".equals(t)) return "лабораторная работа";
        if ("се".equals(t)) return "семинар";
        return "";
    }

    private static String minutesWord(int n) {
        int m10 = n % 10, m100 = n % 100;
        if (m10 == 1 && m100 != 11) return "минута";
        if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return "минуты";
        return "минут";
    }

    /** «3/303» → «корпус 3, аудитория 303» — так понятнее на слух */
    private static String roomWords(String room) {
        int i = room.indexOf('/');
        if (i > 0) return "корпус " + room.substring(0, i).trim() + ", аудитория " + room.substring(i + 1).trim();
        return "аудитория " + room;
    }

    /** Текст голосового напоминания: время, номер пары, предмет, аудитория, кто проводит / у какой группы. */
    static String speechText(Context c, Pair p, int min) {
        Lesson l = p.lessons.get(0);
        String k = kind(c);
        String ord = p.n > 0 && p.n < ORD.length ? ORD[p.n] + " пара" : p.n + "-я пара";
        StringBuilder sb = new StringBuilder();
        String mw = minutesWord(min);
        String acc = "минута".equals(mw) ? "минуту" : mw; // «через 1 минуту»
        if ("room".equals(k)) sb.append("Через ").append(min).append(' ').append(acc).append(" в этой аудитории начнётся ").append(ord).append(". ");
        else sb.append("До занятия ").append("минута".equals(mw) ? "осталась " : "осталось ").append(min).append(' ').append(mw)
                .append(". Начинается ").append(ord).append(". ");
        String tw = typeWord(l.type);
        sb.append(l.subject).append(tw.isEmpty() ? "" : ", " + tw).append(". ");
        if (!"room".equals(k) && !l.room.isEmpty()) sb.append("Занятие пройдёт: ").append(roomWords(l.room)).append(". ");
        if (!"group".equals(k) && !l.group.isEmpty())
            sb.append("У группы ").append(l.group).append(l.sub.isEmpty() ? "" : ", " + l.sub + " подгруппа").append(". ");
        if (!"teacher".equals(k) && !l.teacher.isEmpty()) sb.append("Проводит ").append(l.teacher.replaceAll("\\.+$", "")).append(". ");
        if ("group".equals(k) && !l.sub.isEmpty()) sb.append("Для ").append(l.sub).append(" подгруппы.");
        return sb.toString().trim();
    }

    static String typeShort(String t) {
        if ("лк".equals(t)) return "лк.";
        if ("пр".equals(t)) return "пр.";
        if ("лб".equals(t) || "ла".equals(t)) return "лаб.";
        if ("се".equals(t)) return "сем.";
        return "";
    }

    static String duration(int min) {
        min = Math.max(0, min);
        int h = min / 60, m = min % 60;
        if (h > 0 && m > 0) return h + " ч " + m + " мин";
        if (h > 0) return h + " ч";
        return m + " мин";
    }

    static String join(List<String> items, String sep) { return TextUtils.join(sep, items); }
}
