package kg.oshtu.schedule;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Виджет «Пары сегодня» для рабочего стола. */
public class ScheduleWidget extends AppWidgetProvider {
    static final String ACT_PREV = "kg.oshtu.schedule.PREV";
    static final String ACT_NEXT = "kg.oshtu.schedule.NEXT";
    static final String ACT_RESET = "kg.oshtu.schedule.RESET";
    static final String ACT_REFRESH = "kg.oshtu.schedule.REFRESH";
    static final String ACT_TICK = "kg.oshtu.schedule.TICK";

    private static final int ROWS = 6;
    private static final int C_TEXT = Color.parseColor("#EEF0FA");
    private static final int C_MUTED = Color.parseColor("#8D92AB");
    private static final int C_ACCENT = Color.parseColor("#9D9DFF");
    private static final int C_PAST = Color.parseColor("#5A5F78");
    private static final Locale RU = new Locale("ru");

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        String a = intent.getAction();
        if (a == null) a = "";
        final Context app = ctx.getApplicationContext();

        if (ACT_PREV.equals(a) || ACT_NEXT.equals(a)) {
            Schedule.shiftOffset(app, ACT_NEXT.equals(a) ? 1 : -1);
            renderAll(app);
            return;
        }

        boolean ours = ACT_RESET.equals(a) || ACT_REFRESH.equals(a) || ACT_TICK.equals(a)
                || AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a);
        if (!ours) {
            super.onReceive(ctx, intent);
            return;
        }
        if (ACT_RESET.equals(a)) Schedule.shiftOffset(app, 0);

        renderAll(app); // мгновенно из кэша

        long age = System.currentTimeMillis() - Schedule.prefs(app).getLong("cacheAt", 0);
        boolean needFetch = !ACT_TICK.equals(a) || age > 20 * 60 * 1000L;
        if (!needFetch || Schedule.groupId(app) <= 0) return;

        final PendingResult pending = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Schedule.fetch(app);
                } catch (Exception ignored) {
                } finally {
                    renderAll(app);
                    Reminders.schedule(app);
                    pending.finish();
                }
            }
        }).start();
    }

    /** Обновить все экземпляры виджета (вызывается и из приложения). */
    static void renderAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, ScheduleWidget.class));
        if (ids == null || ids.length == 0) return;
        RemoteViews v = build(ctx);
        for (int id : ids) mgr.updateAppWidget(id, v);
        scheduleTick(ctx);
    }

    static void requestRefresh(Context ctx) {
        Intent i = new Intent(ctx, ScheduleWidget.class).setAction(ACT_REFRESH);
        ctx.sendBroadcast(i);
    }

    private static PendingIntent broadcast(Context ctx, String action, int code) {
        Intent i = new Intent(ctx, ScheduleWidget.class).setAction(action);
        return PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static int id(Context ctx, String name) {
        return ctx.getResources().getIdentifier(name, "id", ctx.getPackageName());
    }

    private static String cap(String s) {
        return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(RU) + s.substring(1);
    }

    static RemoteViews build(Context ctx) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget);

        Intent open = new Intent(ctx, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        v.setOnClickPendingIntent(R.id.rows, PendingIntent.getActivity(ctx, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        v.setOnClickPendingIntent(R.id.empty, PendingIntent.getActivity(ctx, 11, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        v.setOnClickPendingIntent(R.id.btn_prev, broadcast(ctx, ACT_PREV, 1));
        v.setOnClickPendingIntent(R.id.btn_next, broadcast(ctx, ACT_NEXT, 2));
        v.setOnClickPendingIntent(R.id.header, broadcast(ctx, ACT_RESET, 3));
        v.setOnClickPendingIntent(R.id.footer, broadcast(ctx, ACT_REFRESH, 4));

        for (int i = 1; i <= ROWS; i++) v.setViewVisibility(id(ctx, "row" + i), View.GONE);
        v.setViewVisibility(R.id.status, View.GONE);

        if (Schedule.groupId(ctx) <= 0) {
            v.setTextViewText(R.id.title, "Расписание ОшТУ");
            v.setTextViewText(R.id.sub, "");
            v.setViewVisibility(R.id.empty, View.VISIBLE);
            v.setTextViewText(R.id.empty, "Открой приложение и выбери группу, преподавателя или аудиторию");
            v.setTextViewText(R.id.footer, "");
            return v;
        }

        Calendar day = Schedule.shownDay(ctx);
        Calendar today = Schedule.today();
        long diff = Math.round((day.getTimeInMillis() - today.getTimeInMillis()) / 86400000.0);
        String title;
        if (diff == 0) title = "Сегодня";
        else if (diff == 1) title = "Завтра";
        else if (diff == -1) title = "Вчера";
        else title = cap(new SimpleDateFormat("EEEE", RU).format(day.getTime()));
        v.setTextViewText(R.id.title, title);
        String week = Schedule.isTopWeek(day, Schedule.flip(ctx)) ? "верхняя" : "нижняя";
        v.setTextViewText(R.id.sub, new SimpleDateFormat("EE, d MMM", RU).format(day.getTime()) + " · " + week);

        if (!Schedule.hasCache(ctx)) {
            v.setViewVisibility(R.id.empty, View.VISIBLE);
            v.setTextViewText(R.id.empty, "Загрузка…");
            v.setTextViewText(R.id.footer, Schedule.groupName(ctx));
            return v;
        }

        List<Schedule.Pair> list = Schedule.lessonsOn(ctx, day);
        boolean isToday = diff == 0;
        int now = Schedule.nowMinutes();

        if (list.isEmpty()) {
            v.setViewVisibility(R.id.empty, View.VISIBLE);
            v.setTextViewText(R.id.empty, Schedule.isoDow(day) == 7 ? "Воскресенье — выходной" : "Пар нет 🎉");
        } else {
            v.setViewVisibility(R.id.empty, View.GONE);
        }

        String status = null;
        for (int i = 0; i < list.size() && i < ROWS; i++) {
            Schedule.Pair p = list.get(i);
            int k = i + 1;
            int row = id(ctx, "row" + k);
            v.setViewVisibility(row, View.VISIBLE);
            Schedule.Lesson l = p.lessons.get(0);
            String type = Schedule.typeShort(l.type);
            String subj = l.subject + (type.isEmpty() ? "" : " (" + type + ")")
                    + (p.lessons.size() > 1 ? " +" + (p.lessons.size() - 1) : "");
            v.setTextViewText(id(ctx, "n" + k), String.valueOf(p.n));
            v.setTextViewText(id(ctx, "t" + k), p.start != null ? p.start : "");
            v.setTextViewText(id(ctx, "s" + k), subj);
            v.setTextViewText(id(ctx, "r" + k), Schedule.rightInfo(ctx, l));

            boolean cur = false, past = false;
            if (isToday && p.start != null) {
                int s = Schedule.minutes(p.start), e = Schedule.minutes(p.end);
                if (now >= e) past = true;
                else if (now >= s) {
                    cur = true;
                    status = "Сейчас " + p.n + "-я пара · ещё " + Schedule.duration(e - now);
                } else if (status == null) {
                    status = (i == 0 ? "Первая пара" : "Дальше " + p.n + "-я пара") + " через " + Schedule.duration(s - now);
                }
            }
            v.setInt(row, "setBackgroundResource", cur ? R.drawable.row_now : 0);
            int main = past ? C_PAST : C_TEXT;
            int sub = cur ? C_TEXT : past ? C_PAST : C_MUTED;
            v.setTextColor(id(ctx, "s" + k), main);
            v.setTextColor(id(ctx, "t" + k), sub);
            v.setTextColor(id(ctx, "r" + k), sub);
            v.setTextColor(id(ctx, "n" + k), cur ? C_TEXT : past ? C_PAST : C_ACCENT);
        }
        if (isToday && status == null && !list.isEmpty()) status = "Пары на сегодня закончились";
        if (!isToday && diff > 0 && Schedule.sameDay(day, Schedule.baseDay(ctx)) && Schedule.isoDow(today) <= 6
                && !list.isEmpty()) {
            status = "Сегодня пары закончились · первая в " + list.get(0).start;
        }
        if (status != null) {
            v.setViewVisibility(R.id.status, View.VISIBLE);
            v.setTextViewText(R.id.status, status);
        }

        long at = Schedule.prefs(ctx).getLong("cacheAt", 0);
        String time = at > 0 ? new SimpleDateFormat("HH:mm", RU).format(new Date(at)) : "—";
        boolean failed = Schedule.prefs(ctx).getBoolean("lastFailed", false);
        v.setTextViewText(R.id.footer, Schedule.groupName(ctx) + " · " + (failed ? "нет сети, копия от " : "обновлено ") + time + "  ⟳");
        return v;
    }

    /** Следующее обновление — на границе пары (или через 15 минут). */
    static void scheduleTick(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        int now = Schedule.nowMinutes();
        int next = now + 15;
        for (Schedule.Pair p : Schedule.lessonsOn(ctx, Schedule.today())) {
            if (p.start == null) continue;
            int s = Schedule.minutes(p.start), e = Schedule.minutes(p.end);
            if (s > now) next = Math.min(next, s);
            if (e > now) next = Math.min(next, e);
        }
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 5);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.MINUTE, next);
        PendingIntent pi = broadcast(ctx, ACT_TICK, 5);
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC, c.getTimeInMillis(), pi);
        else am.set(AlarmManager.RTC, c.getTimeInMillis(), pi);
    }

    @Override
    public void onDisabled(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(broadcast(ctx, ACT_TICK, 5));
    }
}
